<?php
/**
 * Single product: big photo gallery with a lamplight lens, buy box with size and
 * colour buttons, "Add a little extra" right under the button, details in accordions,
 * room photos, the making story, then "Complete the look" and reviews.
 *
 * @package designer-designs
 * @version 3.6.0
 */

defined( 'ABSPATH' ) || exit;

global $product;

do_action( 'woocommerce_before_single_product' );
if ( post_password_required() ) {
	echo get_the_password_form(); // phpcs:ignore
	return;
}

$dd_ids = array_values( array_filter( array_merge( array( $product->get_image_id() ), $product->get_gallery_image_ids() ) ) );
$dd_n   = count( $dd_ids );
$dd_gal = array();
foreach ( $dd_ids as $dd_id ) {
	$dd_gal[] = array(
		'id'    => $dd_id,
		'src'   => wp_get_attachment_image_url( $dd_id, 'dd-large' ),
		'full'  => wp_get_attachment_image_url( $dd_id, 'full' ),
		'thumb' => wp_get_attachment_image_url( $dd_id, 'dd-thumb' ),
		'alt'   => get_post_meta( $dd_id, '_wp_attachment_image_alt', true ) ?: $product->get_name(),
		'cap'   => wp_get_attachment_caption( $dd_id ),
	);
}
$dd_kicker   = $product->get_meta( '_dd_kicker' );
$dd_lead     = $product->get_meta( '_dd_lead_time' ) ?: dd_mod( 'dd_lead_default' );
$dd_extras   = dd_extras( array( $product->get_id() ), array( $product->get_id() ), 3 );
$dd_rating   = (float) $product->get_average_rating();
$dd_rcount   = (int) $product->get_review_count();
$dd_commiss  = get_page_by_path( 'commissions' );
$dd_delivery = $product->get_meta( '_dd_delivery' ) ?: get_option( 'dd_default_delivery', '' );
?>
<div id="product-<?php the_ID(); ?>" <?php wc_product_class( 'dd-product', $product ); ?>>

	<div class="dd-pdp">
		<div class="dd-gallery" data-dd-gallery>
			<?php if ( $dd_n > 1 ) : ?>
				<div class="dd-gallery__thumbs" role="group" aria-label="<?php esc_attr_e( 'Product photos', 'designer-designs' ); ?>">
					<?php foreach ( $dd_gal as $dd_i => $dd_g ) : ?>
						<button type="button" class="dd-thumb" data-dd-thumb="<?php echo esc_attr( $dd_i ); ?>" aria-current="<?php echo 0 === $dd_i ? 'true' : 'false'; ?>" aria-label="<?php echo esc_attr( sprintf( __( 'Show image %1$d: %2$s', 'designer-designs' ), $dd_i + 1, $dd_g['alt'] ) ); ?>">
							<img src="<?php echo esc_url( $dd_g['thumb'] ); ?>" alt="" width="84" height="105" loading="lazy">
						</button>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
			<div class="dd-gallery__main">
				<div class="dd-stage" data-dd-stage data-images="<?php echo esc_attr( wp_json_encode( $dd_gal ) ); ?>">
					<?php if ( $dd_gal ) : ?>
						<img data-dd-main src="<?php echo esc_url( $dd_gal[0]['src'] ); ?>" alt="<?php echo esc_attr( $dd_gal[0]['alt'] ); ?>" width="1400" height="1750" fetchpriority="high">
					<?php else : ?>
						<?php echo wc_placeholder_img( 'dd-large' ); // phpcs:ignore ?>
					<?php endif; ?>
					<span class="dd-lens" aria-hidden="true"><img alt="" src="<?php echo esc_url( $dd_gal ? $dd_gal[0]['full'] : '' ); ?>"></span>
					<?php if ( $dd_n > 1 ) : ?>
						<div class="dd-stage__nav">
							<span data-dd-counter>1 / <?php echo esc_html( $dd_n ); ?></span>
							<button type="button" class="dd-icon-btn" data-dd-prev aria-label="<?php esc_attr_e( 'Previous image', 'designer-designs' ); ?>"><?php echo dd_icon( 'left' ); // phpcs:ignore ?></button>
							<button type="button" class="dd-icon-btn" data-dd-next aria-label="<?php esc_attr_e( 'Next image', 'designer-designs' ); ?>"><?php echo dd_icon( 'right' ); // phpcs:ignore ?></button>
						</div>
					<?php endif; ?>
				</div>
				<p class="dd-gallery__hint"><?php esc_html_e( 'Hover the photo to look closely at the texture', 'designer-designs' ); ?></p>
			</div>
		</div>

		<div class="dd-buy summary entry-summary">
			<?php if ( $dd_kicker ) : ?>
				<p class="dd-buy__kicker"><?php echo esc_html( $dd_kicker ); ?></p>
			<?php endif; ?>
			<div style="display:flex;flex-direction:column;gap:14px">
				<?php the_title( '<h1 class="product_title entry-title">', '</h1>' ); ?>
				<?php $dd_sc = dd_size_count( $product ); ?>
				<?php if ( $dd_sc > 1 ) : ?>
					<a class="dd-size-chip" href="#dd-buyform"><?php echo esc_html( sprintf( __( 'Made in %d sizes: Small, Medium and Large', 'designer-designs' ), $dd_sc ) ); ?></a>
				<?php endif; ?>
				<?php if ( $dd_rcount ) : ?>
					<a class="dd-buy__rating" href="#reviews"><span class="dd-stars" style="font-size:15px" aria-hidden="true">★★★★★</span><?php echo esc_html( sprintf( _n( '%1$s from %2$d review', '%1$s from %2$d reviews', $dd_rcount, 'designer-designs' ), number_format_i18n( $dd_rating, 1 ), $dd_rcount ) ); ?></a>
				<?php else : ?>
					<?php list( $dd_avg, $dd_cnt ) = dd_store_rating(); ?>
					<?php if ( $dd_avg ) : ?>
						<a class="dd-buy__rating" href="#reviews"><span class="dd-stars" style="font-size:15px" aria-hidden="true">★★★★★</span><?php echo esc_html( sprintf( __( '%1$s from %2$d shop reviews', 'designer-designs' ), number_format_i18n( $dd_avg, 1 ), $dd_cnt ) ); ?></a>
					<?php endif; ?>
				<?php endif; ?>
				<div>
					<p class="price" data-dd-price><?php echo wp_kses_post( $product->get_price_html() ); ?></p>
					<?php if ( dd_mod( 'dd_klarna' ) && $product->get_price() ) : ?>
						<p class="dd-buy__klarna" data-dd-klarna data-price="<?php echo esc_attr( wc_get_price_to_display( $product ) ); ?>" style="margin-top:10px">
							<?php printf( esc_html__( 'or 3 interest-free payments of %s with Klarna', 'designer-designs' ), wp_kses_post( wc_price( wc_get_price_to_display( $product ) / 3 ) ) ); ?>
						</p>
					<?php endif; ?>
				</div>
			</div>

			<?php if ( $product->get_short_description() ) : ?>
				<div class="woocommerce-product-details__short-description"><?php echo wp_kses_post( wpautop( $product->get_short_description() ) ); ?></div>
			<?php endif; ?>

			<div id="dd-buyform" data-dd-buyform data-swatches="<?php echo esc_attr( wp_json_encode( dd_swatch_data( $product ) ) ); ?>">
				<?php woocommerce_template_single_add_to_cart(); ?>
			</div>

			<?php if ( $product->is_type( 'variable' ) ) : ?>
				<div class="dd-size-help">
					<?php if ( dd_page_url( 'size-guide' ) ) : ?>
						<a href="<?php echo esc_url( dd_page_url( 'size-guide' ) ); ?>"><?php esc_html_e( 'Size guide', 'designer-designs' ); ?></a>
					<?php endif; ?>
					<button type="button" class="dd-link" data-dd-goto-scale><?php esc_html_e( 'See it next to a person', 'designer-designs' ); ?></button>
					<?php if ( $dd_commiss ) : ?>
						<a href="<?php echo esc_url( get_permalink( $dd_commiss ) ); ?>"><?php esc_html_e( 'Need another size? Ask for a custom piece', 'designer-designs' ); ?></a>
					<?php endif; ?>
				</div>
			<?php endif; ?>

			<?php if ( $dd_lead ) : ?>
				<div class="dd-lead">
					<span style="color:var(--dd-gold-2);margin-top:2px"><?php echo dd_icon( 'clock', 20 ); // phpcs:ignore ?></span>
					<div><strong><?php esc_html_e( 'Made to order for you', 'designer-designs' ); ?></strong><span><?php echo esc_html( $dd_lead ); ?></span></div>
				</div>
			<?php endif; ?>
			<p class="dd-trust"><?php printf( esc_html__( 'Free UK delivery over %s. Easy returns. Love It guarantee.', 'designer-designs' ), wp_kses_post( wc_price( dd_free_threshold(), array( 'decimals' => 0 ) ) ) ); ?></p>

			<?php if ( $dd_extras ) : ?>
				<div class="dd-addons">
					<h2 class="dd-extra-title"><?php esc_html_e( 'Add a little extra', 'designer-designs' ); ?></h2>
					<div class="dd-extras__grid">
						<?php foreach ( $dd_extras as $dd_x ) { dd_extra_card( $dd_x ); } ?>
					</div>
				</div>
			<?php endif; ?>

			<div class="dd-acc">
				<?php
				$dd_attr_html = '';
				ob_start();
				wc_display_product_attributes( $product );
				$dd_attr_html = ob_get_clean();
				$dd_panels    = array(
					__( 'Details and dimensions', 'designer-designs' ) => wpautop( wp_kses_post( $product->get_description() ) ) . ( $product->has_dimensions() || $product->has_weight() || $product->get_attributes() ? $dd_attr_html : '' ),
					__( 'Materials and finish', 'designer-designs' )   => wpautop( esc_html( $product->get_meta( '_dd_materials' ) ) ),
					__( 'Care, and what is in the box', 'designer-designs' ) => wpautop( esc_html( $product->get_meta( '_dd_care' ) ) ),
					__( 'Delivery and returns', 'designer-designs' )   => wpautop( esc_html( $dd_delivery ) ),
				);
				$dd_first = true;
				foreach ( $dd_panels as $dd_title => $dd_body ) {
					if ( ! trim( wp_strip_all_tags( $dd_body ) ) ) {
						continue;
					}
					printf(
						'<details%s><summary>%s<span>%s</span></summary><div class="dd-acc__body">%s</div></details>',
						$dd_first ? ' open' : '',
						esc_html( $dd_title ),
						dd_icon( 'plus', 18 ), // phpcs:ignore
						$dd_body // phpcs:ignore -- escaped above.
					);
					$dd_first = false;
				}
				?>
			</div>
		</div>
	</div>

	<?php
	// Room photos: gallery images that have a caption.
	$dd_rooms = array_values( array_filter( $dd_gal, fn( $g ) => ! empty( $g['cap'] ) ) );
	?>
	<?php if ( $dd_rooms ) : ?>
		<section class="dd-rooms" aria-label="<?php esc_attr_e( 'In the room', 'designer-designs' ); ?>" style="margin:0 calc(var(--dd-pad) * -1)">
			<?php foreach ( array_slice( $dd_rooms, 0, 2 ) as $dd_g ) : ?>
				<figure><img src="<?php echo esc_url( $dd_g['src'] ); ?>" alt="<?php echo esc_attr( $dd_g['alt'] ); ?>" loading="lazy" width="1400" height="1750"><figcaption><?php echo esc_html( $dd_g['cap'] ); ?></figcaption></figure>
			<?php endforeach; ?>
		</section>
	<?php endif; ?>

	<?php $dd_story = $product->get_meta( '_dd_story' ); ?>
	<?php if ( $dd_story ) : ?>
		<?php $dd_close = array_slice( array_values( array_filter( $dd_gal, fn( $g ) => empty( $g['cap'] ) ) ), -2 ); ?>
		<section class="dd-section dd-story" aria-labelledby="dd-story-title">
			<?php if ( count( $dd_close ) === 2 ) : ?>
				<div class="dd-story__imgs">
					<?php foreach ( $dd_close as $dd_g ) : ?>
						<img src="<?php echo esc_url( $dd_g['src'] ); ?>" alt="<?php echo esc_attr( $dd_g['alt'] ); ?>" loading="lazy" width="700" height="933">
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
			<div class="dd-story__text">
				<h2 id="dd-story-title"><?php echo esc_html( $product->get_meta( '_dd_story_title' ) ?: __( 'Shaped by hand, so no two are the same', 'designer-designs' ) ); ?></h2>
				<p><?php echo esc_html( $dd_story ); ?></p>
				<div class="dd-kit">
					<div><strong><?php esc_html_e( 'Detail brush', 'designer-designs' ); ?></strong><span><?php esc_html_e( 'Lifts dust from deep texture.', 'designer-designs' ); ?></span></div>
					<div><strong><?php esc_html_e( 'Soft cloth', 'designer-designs' ); ?></strong><span><?php esc_html_e( 'For the shade and smooth areas.', 'designer-designs' ); ?></span></div>
					<div><strong><?php esc_html_e( 'Care card', 'designer-designs' ); ?></strong><span><?php esc_html_e( 'Written for your finish.', 'designer-designs' ); ?></span></div>
				</div>
			</div>
		</section>
	<?php endif; ?>

	<?php
	woocommerce_upsell_display();
	woocommerce_output_related_products();
	comments_template();
	?>
</div>

<?php do_action( 'woocommerce_after_single_product' ); ?>
