<?php
/**
 * Not found.
 *
 * @package designer-designs
 */

get_header();
?>
<main id="main" class="dd-wrap dd-page" style="text-align:center">
	<h1 class="dd-page__title dd-italic"><?php esc_html_e( 'This page has wandered off', 'designer-designs' ); ?></h1>
	<p class="dd-muted" style="margin-bottom:32px"><?php esc_html_e( 'The piece you are looking for may have sold or moved. The collection is a good place to start.', 'designer-designs' ); ?></p>
	<?php if ( function_exists( 'wc_get_page_permalink' ) ) : ?>
		<a class="dd-btn dd-btn--gold" href="<?php echo esc_url( wc_get_page_permalink( 'shop' ) ); ?>"><?php esc_html_e( 'Shop the collection', 'designer-designs' ); ?></a>
	<?php endif; ?>
</main>
<?php
get_footer();
