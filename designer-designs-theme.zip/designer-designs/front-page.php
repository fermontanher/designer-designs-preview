<?php
/**
 * Homepage.
 *
 * Hero: the room is dark and the visitor's cursor is the lamp (approved sample effect).
 * Slides rotate every 6s, pause on hover/focus, stop once the visitor interacts, and
 * do not rotate on touch screens or with reduced motion.
 *
 * @package designer-designs
 */

defined( 'ABSPATH' ) || exit;
get_header();

$dd_shop   = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/' );
$dd_slides = array(
	array( 'hero-1.jpg', __( 'Pebble Floor Lamp glowing in a bedroom at dusk', 'designer-designs' ), '70% 45%', '86%' ),
	array( 'room.jpg', __( 'A dining room at night lit by the Pebble Floor Lamp', 'designer-designs' ), '80% 40%', '88%' ),
	array( 'hero-2.jpg', __( 'Pebble Floor Lamp in a living room beside an armchair', 'designer-designs' ), '60% 40%', '70%' ),
	array( 'hero-3.jpg', __( 'Pebble Floor Lamp in a dining room by day', 'designer-designs' ), '65% 40%', '60%' ),
	array( 'hero-4.jpg', __( 'Pebble Floor Lamp in a bright hallway', 'designer-designs' ), '50% 40%', '50%' ),
);
?>
<main id="main">

	<?php /* Hero: the room starts dark with one lamp switch. Switching it on reveals the work full screen, no text. */ ?>
	<section class="dd-hero dd-hero--clean" data-dd-hero aria-roledescription="<?php esc_attr_e( 'carousel', 'designer-designs' ); ?>" aria-label="<?php esc_attr_e( 'Our work', 'designer-designs' ); ?>">
		<?php foreach ( $dd_slides as $dd_i => $dd_s ) : ?>
			<div class="dd-hero__slide<?php echo 0 === $dd_i ? ' is-active' : ''; ?>" data-dd-slide aria-roledescription="<?php esc_attr_e( 'slide', 'designer-designs' ); ?>" aria-label="<?php echo esc_attr( sprintf( '%d / %d', $dd_i + 1, count( $dd_slides ) ) ); ?>" <?php echo 0 === $dd_i ? '' : 'aria-hidden="true"'; ?>>
				<img src="<?php echo dd_img( $dd_s[0] ); // phpcs:ignore ?>" alt="<?php echo esc_attr( $dd_s[1] ); ?>" style="object-position:<?php echo esc_attr( $dd_s[2] ); ?>;--mpos:<?php echo esc_attr( $dd_s[3] ?? '50%' ); ?>" <?php echo 0 === $dd_i ? 'fetchpriority="high"' : 'loading="lazy"'; ?> width="1600" height="1280">
			</div>
		<?php endforeach; ?>
		<div class="dd-hero__dark" aria-hidden="true"></div>

		<div class="dd-hero__switch">
			<button type="button" class="dd-lamp" data-dd-lamp aria-pressed="false">
				<span class="dd-lamp__icon"><?php echo dd_icon( 'lamp', 26 ); // phpcs:ignore ?></span>
				<span class="dd-lamp__label"><?php esc_html_e( 'Switch the light on', 'designer-designs' ); ?></span>
			</button>
		</div>

		<div class="dd-hero__controls">
			<?php foreach ( $dd_slides as $dd_i => $dd_s ) : ?>
				<button type="button" class="dd-hero__dot" data-dd-dot="<?php echo esc_attr( $dd_i ); ?>" aria-current="<?php echo 0 === $dd_i ? 'true' : 'false'; ?>" aria-label="<?php echo esc_attr( sprintf( __( 'Show photo %d', 'designer-designs' ), $dd_i + 1 ) ); ?>"><span></span></button>
			<?php endforeach; ?>
		</div>
		<a class="dd-hero__down" href="#dd-intro" aria-label="<?php esc_attr_e( 'Scroll to the collection', 'designer-designs' ); ?>"><span></span></a>
	</section>

	<section class="dd-intro dd-wrap" id="dd-intro" aria-labelledby="dd-intro-title">
		<p class="dd-hero__kicker"><?php echo esc_html( dd_mod( 'dd_hero_kicker' ) ); ?></p>
		<h1 id="dd-intro-title" class="dd-intro__title dd-foil-text"><?php echo esc_html( dd_mod( 'dd_hero_title' ) ); ?></h1>
		<p class="dd-hero__lead"><?php echo esc_html( dd_mod( 'dd_hero_lead' ) ); ?></p>
		<a class="dd-btn dd-btn--gold" href="<?php echo esc_url( $dd_shop ); ?>"><?php esc_html_e( 'Shop the collection', 'designer-designs' ); ?></a>
	</section>

	<?php $dd_cats = dd_nav_categories(); ?>
	<?php if ( $dd_cats ) : ?>
	<section class="dd-wrap dd-section" aria-labelledby="dd-find">
		<div class="dd-section-head">
			<h2 id="dd-find" class="dd-h2"><?php esc_html_e( 'Find your piece', 'designer-designs' ); ?></h2>
			<p><?php esc_html_e( 'Every piece is made to order in our London studio, in the finish you choose.', 'designer-designs' ); ?></p>
		</div>
		<div class="dd-tiles">
			<?php foreach ( $dd_cats as $dd_cat ) : ?>
				<a class="dd-tile" href="<?php echo esc_url( get_term_link( $dd_cat ) ); ?>">
					<img src="<?php echo esc_url( dd_category_image( $dd_cat ) ); ?>" alt="" loading="lazy" width="640" height="800">
					<span class="dd-tile__warm" aria-hidden="true"></span>
					<span class="dd-tile__shade" aria-hidden="true"></span>
					<span class="dd-tile__label">
						<strong><?php echo esc_html( $dd_cat->name ); ?></strong>
						<span><?php echo esc_html( dd_category_soon( $dd_cat ) ? __( 'Coming soon', 'designer-designs' ) : dd_category_note( $dd_cat ) ); ?></span>
					</span>
				</a>
			<?php endforeach; ?>
		</div>
	</section>
	<?php endif; ?>

	<?php
	$dd_best = function_exists( 'wc_get_products' ) ? wc_get_products( array( 'status' => 'publish', 'limit' => 4, 'featured' => true ) ) : array();
	if ( count( $dd_best ) < 4 && function_exists( 'wc_get_products' ) ) {
		$dd_best = wc_get_products( array( 'status' => 'publish', 'limit' => 4, 'orderby' => 'popularity' ) );
	}
	?>
	<?php if ( $dd_best ) : ?>
	<section class="dd-wrap" style="padding-bottom:clamp(72px,9vw,128px)" aria-labelledby="dd-best">
		<div class="dd-section-head">
			<h2 id="dd-best" class="dd-h2"><?php esc_html_e( 'Most loved', 'designer-designs' ); ?></h2>
			<a href="<?php echo esc_url( $dd_shop ); ?>" style="font-weight:500"><?php esc_html_e( 'See every piece', 'designer-designs' ); ?></a>
		</div>
		<ul class="products dd-products">
			<?php
			foreach ( $dd_best as $dd_p ) {
				$GLOBALS['product'] = $dd_p; // phpcs:ignore
				$GLOBALS['post']    = get_post( $dd_p->get_id() ); // phpcs:ignore
				setup_postdata( $GLOBALS['post'] );
				wc_get_template_part( 'content', 'product' );
			}
			wp_reset_postdata();
			?>
		</ul>
	</section>
	<?php endif; ?>

	<?php
	$dd_pebble = function_exists( 'wc_get_product_id_by_sku' ) ? wc_get_product( wc_get_product_id_by_sku( 'DD-PEBBLE' ) ) : null;
	$dd_url    = $dd_pebble ? $dd_pebble->get_permalink() : $dd_shop;
	?>
	<section class="dd-room" data-dd-room aria-labelledby="dd-room-title">
		<img class="dd-room__img" src="<?php echo dd_img( 'room.jpg' ); // phpcs:ignore ?>" alt="<?php esc_attr_e( 'A dining room at night lit by the Pebble Floor Lamp', 'designer-designs' ); ?>" loading="lazy" width="1600" height="1279">
		<div class="dd-room__glow" aria-hidden="true"></div>
		<div class="dd-room__fade" aria-hidden="true"></div>
		<div class="dd-room__text">
			<h2 id="dd-room-title"><?php esc_html_e( 'Sculpture by day. A warm glow by night.', 'designer-designs' ); ?></h2>
			<p><?php esc_html_e( 'The Pebble Floor Lamp stands 160 cm tall. Each stacked form is shaped by hand, so the light falls a little differently on every one.', 'designer-designs' ); ?></p>
			<a class="dd-btn" href="<?php echo esc_url( $dd_url ); ?>" style="align-self:flex-start"><?php esc_html_e( 'See the Pebble Floor Lamp', 'designer-designs' ); ?></a>
		</div>
		<?php if ( $dd_pebble ) : ?>
		<div class="dd-hot" data-dd-hot style="left:82%;top:40%">
			<button type="button" class="dd-hot__btn" aria-expanded="false" aria-label="<?php echo esc_attr( sprintf( __( 'Shop the %s', 'designer-designs' ), $dd_pebble->get_name() ) ); ?>"><?php echo dd_icon( 'plus', 18 ); // phpcs:ignore ?></button>
			<div class="dd-hot__card">
				<?php echo $dd_pebble->get_image( 'dd-thumb', array( 'alt' => '' ) ); // phpcs:ignore ?>
				<div style="display:flex;flex-direction:column;gap:6px">
					<strong class="dd-serif" style="font-weight:400;font-size:19px;line-height:1.2"><?php echo esc_html( $dd_pebble->get_name() ); ?></strong>
					<span style="color:var(--dd-gold-text)"><?php echo wp_kses_post( $dd_pebble->get_price_html() ); ?></span>
					<a href="<?php echo esc_url( $dd_url ); ?>" style="font-size:14px;font-weight:500"><?php esc_html_e( 'View piece', 'designer-designs' ); ?></a>
				</div>
			</div>
		</div>
		<?php endif; ?>
	</section>

	<section class="dd-veins" data-dd-veins aria-labelledby="dd-veins-title">
		<div class="dd-veins__layer" aria-hidden="true">
			<img class="dd-veins__dim" src="<?php echo dd_img( 'gold-vein-dark.jpg' ); // phpcs:ignore ?>" alt="" loading="lazy">
			<img class="dd-veins__bright" src="<?php echo dd_img( 'gold-vein-dark.jpg' ); // phpcs:ignore ?>" alt="" loading="lazy">
		</div>
		<div class="dd-veins__content">
			<img src="<?php echo dd_img( 'logo-symbol-gold.png' ); // phpcs:ignore ?>" alt="" width="64" height="64" loading="lazy">
			<h2 id="dd-veins-title" class="dd-veins__quote"><?php esc_html_e( 'Every crack, ridge and fold is left on purpose. That is where the light lives.', 'designer-designs' ); ?></h2>
			<p><?php esc_html_e( 'Organic paper and natural clay are layered by hand in the studio, then finished in matte black, gold and earth tones. We keep the marks of making instead of sanding them away.', 'designer-designs' ); ?></p>
		</div>
		<div class="dd-promises">
			<div><strong><?php esc_html_e( 'Made to order for you', 'designer-designs' ); ?></strong><span><?php esc_html_e( 'Choose the colour and size; the lead time is shown on every piece before you buy.', 'designer-designs' ); ?></span></div>
			<div><strong><?php esc_html_e( 'A care kit in every box', 'designer-designs' ); ?></strong><span><?php esc_html_e( 'A detail brush, a soft cloth and a care card written for your finish.', 'designer-designs' ); ?></span></div>
			<div><strong><?php esc_html_e( 'The Love It guarantee', 'designer-designs' ); ?></strong><span><?php esc_html_e( "If something isn't right for your room, talk to us and we'll put it right.", 'designer-designs' ); ?></span></div>
		</div>
	</section>

	<?php
	list( $dd_avg, $dd_n, $dd_src ) = dd_store_rating();
	$dd_reviews = get_comments( array( 'type' => 'review', 'status' => 'approve', 'number' => 3, 'meta_query' => array( array( 'key' => 'rating', 'value' => 4, 'compare' => '>=', 'type' => 'NUMERIC' ) ) ) ); // phpcs:ignore
	?>
	<?php if ( $dd_avg || $dd_reviews ) : ?>
	<section class="dd-wrap dd-section" aria-labelledby="dd-rev">
		<h2 id="dd-rev" class="screen-reader-text"><?php esc_html_e( 'Reviews', 'designer-designs' ); ?></h2>
		<?php if ( $dd_avg ) : ?>
			<div class="dd-score">
				<span class="dd-score__num dd-foil-text"><?php echo esc_html( number_format_i18n( $dd_avg, 1 ) ); ?></span>
				<div>
					<div class="dd-stars" aria-label="<?php echo esc_attr( sprintf( __( 'Rated %s out of 5', 'designer-designs' ), $dd_avg ) ); ?>">★★★★★</div>
					<p class="dd-muted"><?php echo esc_html( $dd_src ? $dd_src : sprintf( _n( 'From %d review', 'From %d reviews', $dd_n, 'designer-designs' ), $dd_n ) ); ?></p>
				</div>
			</div>
		<?php endif; ?>
		<?php if ( $dd_reviews ) : ?>
			<div class="dd-reviews">
				<?php foreach ( $dd_reviews as $dd_r ) : ?>
					<figure class="dd-review">
						<div class="dd-stars" aria-hidden="true"><?php echo esc_html( str_repeat( '★', (int) get_comment_meta( $dd_r->comment_ID, 'rating', true ) ) ); ?></div>
						<blockquote><?php echo esc_html( wp_trim_words( $dd_r->comment_content, 40 ) ); ?></blockquote>
						<figcaption><?php echo esc_html( $dd_r->comment_author ); ?>, <?php echo esc_html( get_the_title( $dd_r->comment_post_ID ) ); ?></figcaption>
					</figure>
				<?php endforeach; ?>
			</div>
		<?php endif; ?>
	</section>
	<?php endif; ?>

</main>
<?php
get_footer();
