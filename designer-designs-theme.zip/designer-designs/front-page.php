<?php
/**
 * Homepage.
 *
 * Hero: the room is dark and the visitor's cursor is the lamp (approved sample effect).
 * Slides rotate every 6s, pause on hover/focus, stop once the visitor interacts, and
 * do not rotate on touch screens or with reduced motion.
 *
 * @package designer-designs
 */

defined( 'ABSPATH' ) || exit;
get_header();

$dd_shop   = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/' );
// Opening (client feedback 04/11): product-focused images, a few prominent pieces in an
// editorial mosaic, then a moving strip of the other pieces. Starts dark with the light switch.
$dd_feature = array( 'DD-PEBBLE', 'DD-SPHERE', 'DD-WAVE', 'DD-TIERED', 'DD-CAIRN' );
$dd_tiles   = array();
foreach ( $dd_feature as $dd_sku ) {
	$dd_id = function_exists( 'wc_get_product_id_by_sku' ) ? wc_get_product_id_by_sku( $dd_sku ) : 0;
	$dd_p  = $dd_id ? wc_get_product( $dd_id ) : null;
	if ( $dd_p && $dd_p->get_image_id() ) {
		$dd_tiles[] = $dd_p;
	}
}
$dd_strip = function_exists( 'wc_get_products' ) ? wc_get_products( array( 'status' => 'publish', 'limit' => 16, 'exclude' => array_map( fn( $p ) => $p->get_id(), $dd_tiles ), 'orderby' => 'menu_order', 'order' => 'ASC' ) ) : array();
$dd_tile    = function ( $p, $cls, $i ) {
	$sizes = dd_size_count( $p );
	?>
	<a class="dd-mosaic__tile <?php echo esc_attr( $cls ); ?>" href="<?php echo esc_url( $p->get_permalink() ); ?>" style="--i:<?php echo (int) $i; ?>">
		<?php echo wp_get_attachment_image( $p->get_image_id(), 'dd-large', false, array( 'alt' => $p->get_name(), 'loading' => $i < 2 ? 'eager' : 'lazy', 'fetchpriority' => 0 === $i ? 'high' : 'auto' ) ); ?>
		<span class="dd-mosaic__cap">
			<strong><?php echo esc_html( $p->get_name() ); ?></strong>
			<span><?php echo wp_kses_post( $p->get_price_html() ); ?><?php echo $sizes > 1 ? ' · ' . esc_html( sprintf( __( '%d sizes', 'designer-designs' ), $sizes ) ) : ''; ?></span>
		</span>
	</a>
	<?php
};
?>
<main id="main">

	<?php /* Opening (client 04/11: "more innovative / more impressive", like an opening screen that slides open).
	   A gold kintsugi crack draws itself across a dark surface; switching the light on shatters the surface
	   into four shards, light floods out, and the first piece fills the screen before settling into the mosaic. */ ?>
	<div class="dd-intro-curtain" data-dd-curtain data-crack="<?php echo esc_attr( '[[52, -2], [51.68, 4.31], [50.87, 12.51], [51.13, 19.04], [50.81, 24.28], [52.4, 31.3], [50.3, 36.17], [52.18, 41.04], [48.48, 48.31], [51.99, 56.74], [52.03, 63.85], [48.22, 68.98], [46.02, 75.6], [45.76, 80.86], [47.02, 85.48], [50.25, 91.74], [51.06, 98.32], [51.73, 102]]' ); ?>" role="dialog" aria-modal="true" aria-label="<?php esc_attr_e( 'Welcome', 'designer-designs' ); ?>" hidden>
		<div class="dd-curtain__flood" aria-hidden="true"></div>
		<?php foreach ( array( 'lt' => 'polygon(-2% -2%, 52% -2%, 51.68% 4.31%, 50.87% 12.51%, 51.13% 19.04%, 50.81% 24.28%, 52.4% 31.3%, 50.3% 36.17%, 52.18% 41.04%, 48.48% 48.31%, 51.99% 56.74%, 42.99% 58.1%, 33.99% 58.85%, 25.0% 63.56%, 16.0% 65.09%, 7.0% 65.95%, -2% 66%)', 'lb' => 'polygon(-2% 66%, 7.0% 65.95%, 16.0% 65.09%, 25.0% 63.56%, 33.99% 58.85%, 42.99% 58.1%, 51.99% 56.74%, 52.03% 63.85%, 48.22% 68.98%, 46.02% 75.6%, 45.76% 80.86%, 47.02% 85.48%, 50.25% 91.74%, 51.06% 98.32%, 51.73% 102%, -2% 102%)', 'rt' => 'polygon(52% -2%, 51.68% 4.31%, 50.87% 12.51%, 51.13% 19.04%, 50.81% 24.28%, 52.4% 31.3%, 50.3% 36.17%, 58.92% 35.72%, 67.53% 32.63%, 76.15% 30.9%, 84.77% 29.8%, 93.38% 27.47%, 102% 28%, 102% -2%)', 'rb' => 'polygon(102% 28%, 93.38% 27.47%, 84.77% 29.8%, 76.15% 30.9%, 67.53% 32.63%, 58.92% 35.72%, 50.3% 36.17%, 52.18% 41.04%, 48.48% 48.31%, 51.99% 56.74%, 52.03% 63.85%, 48.22% 68.98%, 46.02% 75.6%, 45.76% 80.86%, 47.02% 85.48%, 50.25% 91.74%, 51.06% 98.32%, 51.73% 102%, 102% 102%)' ) as $dd_side => $dd_clip ) : ?>
			<div class="dd-curtain__half dd-curtain__shard dd-curtain__shard--<?php echo esc_attr( $dd_side ); ?>" style="clip-path:<?php echo esc_attr( $dd_clip ); ?>" aria-hidden="<?php echo 'lt' === $dd_side ? 'false' : 'true'; ?>">
				<div class="dd-curtain__face">
					<img class="dd-curtain__logo" src="<?php echo dd_img( 'logo-primary-gold.png' ); // phpcs:ignore ?>" alt="<?php echo 'lt' === $dd_side ? esc_attr( get_bloginfo( 'name' ) ) : ''; ?>" width="420" height="165">
					<p class="dd-curtain__line"><?php esc_html_e( 'Embracing the imperfections', 'designer-designs' ); ?></p>
				</div>
			</div>
		<?php endforeach; ?>
		<div class="dd-curtain__seamwrap" aria-hidden="true">
			<div class="dd-curtain__seam dd-curtain__seam--c" style="clip-path:polygon(51.83% -2%, 51.51% 4.31%, 50.699999999999996% 12.51%, 50.96% 19.04%, 50.64% 24.28%, 52.23% 31.3%, 50.129999999999995% 36.17%, 52.01% 41.04%, 48.309999999999995% 48.31%, 51.82% 56.74%, 51.86% 63.85%, 48.05% 68.98%, 45.85% 75.6%, 45.589999999999996% 80.86%, 46.85% 85.48%, 50.08% 91.74%, 50.89% 98.32%, 51.559999999999995% 102%, 51.9% 102%, 51.230000000000004% 98.32%, 50.42% 91.74%, 47.190000000000005% 85.48%, 45.93% 80.86%, 46.190000000000005% 75.6%, 48.39% 68.98%, 52.2% 63.85%, 52.160000000000004% 56.74%, 48.65% 48.31%, 52.35% 41.04%, 50.47% 36.17%, 52.57% 31.3%, 50.980000000000004% 24.28%, 51.300000000000004% 19.04%, 51.04% 12.51%, 51.85% 4.31%, 52.17% -2%)"></div>
			<div class="dd-curtain__seam dd-curtain__seam--b" style="clip-path:polygon(51.99% 56.580000000000005%, 42.99% 57.940000000000005%, 33.99% 58.690000000000005%, 25.0% 63.400000000000006%, 16.0% 64.93%, 7.0% 65.79%, -2% 65.84%, -2% 66.16%, 7.0% 66.11%, 16.0% 65.25%, 25.0% 63.72%, 33.99% 59.01%, 42.99% 58.26%, 51.99% 56.9%)"></div>
			<div class="dd-curtain__seam dd-curtain__seam--b" style="clip-path:polygon(50.3% 36.010000000000005%, 58.92% 35.56%, 67.53% 32.470000000000006%, 76.15% 30.74%, 84.77% 29.64%, 93.38% 27.31%, 102% 27.84%, 102% 28.16%, 93.38% 27.63%, 84.77% 29.96%, 76.15% 31.06%, 67.53% 32.79%, 58.92% 35.879999999999995%, 50.3% 36.33%)"></div>
		</div>
		<div class="dd-curtain__spark" aria-hidden="true"></div>
		<div class="dd-curtain__ui">
			<button type="button" class="dd-lamp" data-dd-curtain-open>
				<span class="dd-lamp__icon"><?php echo dd_icon( 'lamp', 26 ); // phpcs:ignore ?></span>
				<span class="dd-lamp__label"><?php esc_html_e( 'Switch the light on', 'designer-designs' ); ?></span>
			</button>
		</div>
		<button type="button" class="dd-curtain__skip" data-dd-curtain-skip><?php esc_html_e( 'Skip intro', 'designer-designs' ); ?></button>
	</div>

	<section class="dd-hero dd-hero--mosaic" data-dd-hero aria-label="<?php esc_attr_e( 'Featured pieces', 'designer-designs' ); ?>">
		<div class="dd-mosaic">
			<?php
			$dd_cls = array( 'is-a', 'is-c', 'is-d', 'is-e', 'is-f' );
			foreach ( $dd_tiles as $dd_i => $dd_p ) {
				if ( 1 === $dd_i ) {
					?>
					<div class="dd-mosaic__panel is-b" style="--i:1">
						<img class="dd-mosaic__mark" src="<?php echo dd_img( 'logo-symbol-gold.png' ); // phpcs:ignore ?>" alt="" width="40" height="58">
						<p class="dd-mosaic__kicker"><?php esc_html_e( 'Handmade Homeware', 'designer-designs' ); ?></p>
						<h1 class="dd-mosaic__title dd-foil-text"><?php echo esc_html( dd_mod( 'dd_hero_title' ) ); ?></h1>
						<p class="dd-mosaic__lead"><?php echo esc_html( dd_mod( 'dd_hero_lead' ) ); ?></p>
						<p class="dd-mosaic__sizes"><?php esc_html_e( 'Every piece made to order in Small, Medium and Large', 'designer-designs' ); ?></p>
						<a class="dd-btn dd-btn--gold" href="<?php echo esc_url( $dd_shop ); ?>"><?php esc_html_e( 'Shop the collection', 'designer-designs' ); ?></a>
					</div>
					<?php
				}
				$dd_tile( $dd_p, $dd_cls[ $dd_i ] ?? '', $dd_i + ( $dd_i >= 1 ? 1 : 0 ) );
			}
			?>
		</div>

	</section>

	<?php if ( $dd_strip ) : ?>
	<section class="dd-strip" aria-labelledby="dd-strip-title" data-dd-strip>
		<div class="dd-wrap dd-strip__head">
			<h2 id="dd-strip-title" class="dd-strip__title"><?php esc_html_e( 'More from the studio', 'designer-designs' ); ?></h2>
			<div class="dd-strip__ctrl">
				<button type="button" class="dd-icon-btn" data-dd-strip-prev aria-label="<?php esc_attr_e( 'Previous pieces', 'designer-designs' ); ?>"><?php echo dd_icon( 'left' ); // phpcs:ignore ?></button>
				<button type="button" class="dd-icon-btn" data-dd-strip-next aria-label="<?php esc_attr_e( 'Next pieces', 'designer-designs' ); ?>"><?php echo dd_icon( 'right' ); // phpcs:ignore ?></button>
			</div>
		</div>
		<div class="dd-strip__track" data-dd-strip-track tabindex="0" aria-label="<?php esc_attr_e( 'More pieces, scroll sideways', 'designer-designs' ); ?>">
			<?php foreach ( $dd_strip as $dd_p ) : ?>
				<?php if ( ! $dd_p->get_image_id() ) { continue; } ?>
				<a class="dd-strip__item" href="<?php echo esc_url( $dd_p->get_permalink() ); ?>">
					<?php echo wp_get_attachment_image( $dd_p->get_image_id(), 'dd-card', false, array( 'alt' => '', 'loading' => 'lazy' ) ); ?>
					<span class="dd-strip__name"><?php echo esc_html( $dd_p->get_name() ); ?></span>
					<span class="dd-strip__price"><?php echo wp_kses_post( $dd_p->get_price_html() ); ?></span>
				</a>
			<?php endforeach; ?>
		</div>
	</section>
	<?php endif; ?>

	<?php $dd_cats = dd_nav_categories(); ?>
	<?php if ( $dd_cats ) : ?>
	<section class="dd-wrap dd-section" aria-labelledby="dd-find">
		<div class="dd-section-head">
			<h2 id="dd-find" class="dd-h2"><?php esc_html_e( 'Find your piece', 'designer-designs' ); ?></h2>
			<p><?php esc_html_e( 'Every piece is made to order in our London studio, in the finish you choose.', 'designer-designs' ); ?></p>
		</div>
		<div class="dd-tiles">
			<?php foreach ( $dd_cats as $dd_cat ) : ?>
				<a class="dd-tile" href="<?php echo esc_url( get_term_link( $dd_cat ) ); ?>">
					<img src="<?php echo esc_url( dd_category_image( $dd_cat ) ); ?>" alt="" loading="lazy" width="640" height="800">
					<span class="dd-tile__warm" aria-hidden="true"></span>
					<span class="dd-tile__shade" aria-hidden="true"></span>
					<span class="dd-tile__label">
						<strong><?php echo esc_html( $dd_cat->name ); ?></strong>
						<span><?php echo esc_html( dd_category_soon( $dd_cat ) ? __( 'Coming soon', 'designer-designs' ) : dd_category_note( $dd_cat ) ); ?></span>
					</span>
				</a>
			<?php endforeach; ?>
		</div>
	</section>
	<?php endif; ?>

	<section class="dd-sizes-band" aria-labelledby="dd-sizes-title">
		<div class="dd-wrap dd-section">
			<div class="dd-section-head">
				<div>
					<p class="dd-hero__kicker" style="margin-bottom:10px"><?php esc_html_e( 'Made to fit your space', 'designer-designs' ); ?></p>
					<h2 id="dd-sizes-title" class="dd-h2"><?php esc_html_e( 'One piece, three sizes', 'designer-designs' ); ?></h2>
				</div>
				<p><?php esc_html_e( 'Every design is made to order in Small, Medium and Large, so it can sit on a shelf, stand beside the sofa or fill a whole corner.', 'designer-designs' ); ?></p>
			</div>
			<?php get_template_part( 'template-parts/size-scale' ); ?>
			<div style="display:flex;flex-wrap:wrap;gap:14px;margin-top:36px">
				<?php if ( dd_page_url( 'size-guide' ) ) : ?>
					<a class="dd-btn dd-btn--gold" href="<?php echo esc_url( dd_page_url( 'size-guide' ) ); ?>"><?php esc_html_e( 'Find your size', 'designer-designs' ); ?></a>
				<?php endif; ?>
				<a class="dd-btn" href="<?php echo esc_url( $dd_shop ); ?>"><?php esc_html_e( 'Shop every piece', 'designer-designs' ); ?></a>
			</div>
		</div>
	</section>

	<?php
	$dd_best = function_exists( 'wc_get_products' ) ? wc_get_products( array( 'status' => 'publish', 'limit' => 4, 'featured' => true ) ) : array();
	if ( count( $dd_best ) < 4 && function_exists( 'wc_get_products' ) ) {
		$dd_best = wc_get_products( array( 'status' => 'publish', 'limit' => 4, 'orderby' => 'popularity' ) );
	}
	?>
	<?php if ( $dd_best ) : ?>
	<section class="dd-wrap" style="padding-bottom:clamp(72px,9vw,128px)" aria-labelledby="dd-best">
		<div class="dd-section-head">
			<h2 id="dd-best" class="dd-h2"><?php esc_html_e( 'Most loved', 'designer-designs' ); ?></h2>
			<a href="<?php echo esc_url( $dd_shop ); ?>" style="font-weight:500"><?php esc_html_e( 'See every piece', 'designer-designs' ); ?></a>
		</div>
		<ul class="products dd-products">
			<?php
			foreach ( $dd_best as $dd_p ) {
				$GLOBALS['product'] = $dd_p; // phpcs:ignore
				$GLOBALS['post']    = get_post( $dd_p->get_id() ); // phpcs:ignore
				setup_postdata( $GLOBALS['post'] );
				wc_get_template_part( 'content', 'product' );
			}
			wp_reset_postdata();
			?>
		</ul>
	</section>
	<?php endif; ?>

	<?php
	$dd_pebble = function_exists( 'wc_get_product_id_by_sku' ) ? wc_get_product( wc_get_product_id_by_sku( 'DD-PEBBLE' ) ) : null;
	$dd_url    = $dd_pebble ? $dd_pebble->get_permalink() : $dd_shop;
	?>
	<section class="dd-room" data-dd-room aria-labelledby="dd-room-title">
		<img class="dd-room__img" src="<?php echo dd_img( 'room.jpg' ); // phpcs:ignore ?>" alt="<?php esc_attr_e( 'A dining room at night lit by the Pebble Floor Lamp', 'designer-designs' ); ?>" loading="lazy" width="1600" height="1279">
		<div class="dd-room__glow" aria-hidden="true"></div>
		<div class="dd-room__fade" aria-hidden="true"></div>
		<div class="dd-room__text">
			<h2 id="dd-room-title"><?php esc_html_e( 'Sculpture by day. A warm glow by night.', 'designer-designs' ); ?></h2>
			<p><?php esc_html_e( 'The Pebble Floor Lamp stands 160 cm tall. Each stacked form is shaped by hand, so the light falls a little differently on every one.', 'designer-designs' ); ?></p>
			<a class="dd-btn" href="<?php echo esc_url( $dd_url ); ?>" style="align-self:flex-start"><?php esc_html_e( 'See the Pebble Floor Lamp', 'designer-designs' ); ?></a>
		</div>
		<?php if ( $dd_pebble ) : ?>
		<div class="dd-hot" data-dd-hot style="left:82%;top:40%">
			<button type="button" class="dd-hot__btn" aria-expanded="false" aria-label="<?php echo esc_attr( sprintf( __( 'Shop the %s', 'designer-designs' ), $dd_pebble->get_name() ) ); ?>"><?php echo dd_icon( 'plus', 18 ); // phpcs:ignore ?></button>
			<div class="dd-hot__card">
				<?php echo $dd_pebble->get_image( 'dd-thumb', array( 'alt' => '' ) ); // phpcs:ignore ?>
				<div style="display:flex;flex-direction:column;gap:6px">
					<strong class="dd-serif" style="font-weight:400;font-size:19px;line-height:1.2"><?php echo esc_html( $dd_pebble->get_name() ); ?></strong>
					<span style="color:var(--dd-gold-text)"><?php echo wp_kses_post( $dd_pebble->get_price_html() ); ?></span>
					<a href="<?php echo esc_url( $dd_url ); ?>" style="font-size:14px;font-weight:500"><?php esc_html_e( 'View piece', 'designer-designs' ); ?></a>
				</div>
			</div>
		</div>
		<?php endif; ?>
	</section>

	<section class="dd-veins" data-dd-veins aria-labelledby="dd-veins-title">
		<div class="dd-veins__layer" aria-hidden="true">
			<img class="dd-veins__dim" src="<?php echo dd_img( 'gold-vein-dark.jpg' ); // phpcs:ignore ?>" alt="" loading="lazy">
			<img class="dd-veins__bright" src="<?php echo dd_img( 'gold-vein-dark.jpg' ); // phpcs:ignore ?>" alt="" loading="lazy">
		</div>
		<div class="dd-veins__content">
			<img src="<?php echo dd_img( 'logo-symbol-gold.png' ); // phpcs:ignore ?>" alt="" width="64" height="64" loading="lazy">
			<h2 id="dd-veins-title" class="dd-veins__quote"><?php esc_html_e( 'Every crack, ridge and fold is left on purpose. That is where the light lives.', 'designer-designs' ); ?></h2>
			<p><?php esc_html_e( 'Organic paper and natural clay are layered by hand in the studio, then finished in matte black, gold and earth tones. We keep the marks of making instead of sanding them away.', 'designer-designs' ); ?></p>
		</div>
		<div class="dd-promises">
			<div><strong><?php esc_html_e( 'Made to order for you', 'designer-designs' ); ?></strong><span><?php esc_html_e( 'Choose the colour and size; the lead time is shown on every piece before you buy.', 'designer-designs' ); ?></span></div>
			<div><strong><?php esc_html_e( 'A care kit in every box', 'designer-designs' ); ?></strong><span><?php esc_html_e( 'A detail brush, a soft cloth and a care card written for your finish.', 'designer-designs' ); ?></span></div>
			<div><strong><?php esc_html_e( 'The Love It guarantee', 'designer-designs' ); ?></strong><span><?php esc_html_e( "If something isn't right for your room, talk to us and we'll put it right.", 'designer-designs' ); ?></span></div>
		</div>
	</section>

	<?php
	list( $dd_avg, $dd_n, $dd_src ) = dd_store_rating();
	$dd_reviews = get_comments( array( 'type' => 'review', 'status' => 'approve', 'number' => 3, 'meta_query' => array( array( 'key' => 'rating', 'value' => 4, 'compare' => '>=', 'type' => 'NUMERIC' ) ) ) ); // phpcs:ignore
	?>
	<?php if ( $dd_avg || $dd_reviews ) : ?>
	<section class="dd-wrap dd-section" aria-labelledby="dd-rev">
		<h2 id="dd-rev" class="screen-reader-text"><?php esc_html_e( 'Reviews', 'designer-designs' ); ?></h2>
		<?php if ( $dd_avg ) : ?>
			<div class="dd-score">
				<span class="dd-score__num dd-foil-text"><?php echo esc_html( number_format_i18n( $dd_avg, 1 ) ); ?></span>
				<div>
					<div class="dd-stars" aria-label="<?php echo esc_attr( sprintf( __( 'Rated %s out of 5', 'designer-designs' ), $dd_avg ) ); ?>">★★★★★</div>
					<p class="dd-muted"><?php echo esc_html( $dd_src ? $dd_src : sprintf( _n( 'From %d review', 'From %d reviews', $dd_n, 'designer-designs' ), $dd_n ) ); ?></p>
				</div>
			</div>
		<?php endif; ?>
		<?php if ( $dd_reviews ) : ?>
			<div class="dd-reviews">
				<?php foreach ( $dd_reviews as $dd_r ) : ?>
					<figure class="dd-review">
						<div class="dd-stars" aria-hidden="true"><?php echo esc_html( str_repeat( '★', (int) get_comment_meta( $dd_r->comment_ID, 'rating', true ) ) ); ?></div>
						<blockquote><?php echo esc_html( wp_trim_words( $dd_r->comment_content, 40 ) ); ?></blockquote>
						<figcaption><?php echo esc_html( $dd_r->comment_author ); ?>, <?php echo esc_html( get_the_title( $dd_r->comment_post_ID ) ); ?></figcaption>
					</figure>
				<?php endforeach; ?>
			</div>
		<?php endif; ?>
	</section>
	<?php endif; ?>

</main>
<?php
get_footer();
