<?php
/**
 * Size guide (page slug: size-guide). Scale picture, the page text, then every piece by category.
 *
 * @package designer-designs
 */

get_header();
?>
<main id="main" class="dd-wrap dd-page">
	<p class="dd-hero__kicker"><?php esc_html_e( 'Small, Medium or Large', 'designer-designs' ); ?></p>
	<h1 class="dd-page__title"><?php the_title(); ?></h1>
	<?php
	while ( have_posts() ) :
		the_post();
		echo '<div class="dd-prose" style="margin-bottom:48px">';
		the_content();
		echo '</div>';
	endwhile;
	get_template_part( 'template-parts/size-scale' );
	?>
	<section class="dd-section" aria-labelledby="dd-size-cats">
		<h2 id="dd-size-cats" class="dd-h2" style="margin-bottom:32px"><?php esc_html_e( 'Choose a piece, then its size', 'designer-designs' ); ?></h2>
		<div class="dd-tiles">
			<?php foreach ( dd_nav_categories() as $dd_cat ) : ?>
				<?php if ( dd_category_soon( $dd_cat ) ) { continue; } ?>
				<a class="dd-tile" href="<?php echo esc_url( get_term_link( $dd_cat ) ); ?>">
					<img src="<?php echo esc_url( dd_category_image( $dd_cat ) ); ?>" alt="" loading="lazy" width="640" height="800">
					<span class="dd-tile__warm" aria-hidden="true"></span>
					<span class="dd-tile__shade" aria-hidden="true"></span>
					<span class="dd-tile__label"><strong><?php echo esc_html( $dd_cat->name ); ?></strong><span><?php esc_html_e( 'In 3 sizes', 'designer-designs' ); ?></span></span>
				</a>
			<?php endforeach; ?>
		</div>
	</section>
</main>
<?php
get_footer();
