<?php
/**
 * Customizer settings Elaine can change herself (Appearance → Customise → Designer Designs).
 *
 * @package designer-designs
 */

defined( 'ABSPATH' ) || exit;

/** Defaults in one place, so templates and the Customizer agree. */
function dd_defaults() {
	return array(
		'dd_announce_1'      => 'Free UK delivery on orders over £150',
		'dd_announce_2'      => 'Made to order in London',
		'dd_announce_3'      => 'Pay in 3 with Klarna',
		'dd_free_threshold'  => 150,
		'dd_klarna'          => true,
		'dd_offer_on'        => true,
		'dd_offer_delay'     => 12,
		'dd_offer_title'     => 'Free UK delivery over £150',
		'dd_offer_text'      => 'Every piece is made to order in our London studio and sent tracked, with a care kit in the box.',
		'dd_hero_kicker'     => 'Handmade homeware from a London studio',
		'dd_hero_title'      => 'Embracing the imperfections',
		'dd_hero_lead'       => 'Sculptural lamps, vases and vessels, shaped by hand from paper and clay. No two are ever the same.',
		'dd_footer_about'    => 'A small London studio making sculptural homeware by hand from paper and clay. Every purchase also supports Lupus UK.',
		'dd_rating_override' => '4.9',
		'dd_rating_count'    => 11,
		'dd_rating_source'   => 'From 11 shop reviews on Etsy',
		'dd_ga4_id'          => '',
		'dd_instagram'       => 'https://www.instagram.com/',
		'dd_lead_default'    => 'Made to order: ships in 3 to 4 weeks',
	);
}

/** get_theme_mod with the theme default. */
function dd_mod( $key ) {
	$d = dd_defaults();
	return get_theme_mod( $key, $d[ $key ] ?? '' );
}

add_action( 'customize_register', function ( WP_Customize_Manager $c ) {
	$d = dd_defaults();
	$c->add_panel( 'dd_panel', array( 'title' => __( 'Designer Designs', 'designer-designs' ), 'priority' => 20 ) );

	$sections = array(
		'dd_s_bar'   => __( 'Top banner & offers', 'designer-designs' ),
		'dd_s_hero'  => __( 'Homepage hero', 'designer-designs' ),
		'dd_s_trust' => __( 'Reviews & footer', 'designer-designs' ),
		'dd_s_track' => __( 'Analytics', 'designer-designs' ),
	);
	foreach ( $sections as $id => $title ) {
		$c->add_section( $id, array( 'title' => $title, 'panel' => 'dd_panel' ) );
	}

	$fields = array(
		array( 'dd_announce_1', 'dd_s_bar', 'text', __( 'Banner message 1', 'designer-designs' ) ),
		array( 'dd_announce_2', 'dd_s_bar', 'text', __( 'Banner message 2', 'designer-designs' ) ),
		array( 'dd_announce_3', 'dd_s_bar', 'text', __( 'Banner message 3', 'designer-designs' ) ),
		array( 'dd_free_threshold', 'dd_s_bar', 'number', __( 'Free delivery from (£) — match your Free shipping rule', 'designer-designs' ) ),
		array( 'dd_klarna', 'dd_s_bar', 'checkbox', __( 'Show "Pay in 3 with Klarna" lines', 'designer-designs' ) ),
		array( 'dd_offer_on', 'dd_s_bar', 'checkbox', __( 'Show the free-delivery pop-up', 'designer-designs' ) ),
		array( 'dd_offer_delay', 'dd_s_bar', 'number', __( 'Pop-up delay (seconds)', 'designer-designs' ) ),
		array( 'dd_offer_title', 'dd_s_bar', 'text', __( 'Pop-up title', 'designer-designs' ) ),
		array( 'dd_offer_text', 'dd_s_bar', 'textarea', __( 'Pop-up text', 'designer-designs' ) ),
		array( 'dd_lead_default', 'dd_s_bar', 'text', __( 'Default lead time (when a product has none)', 'designer-designs' ) ),
		array( 'dd_hero_kicker', 'dd_s_hero', 'text', __( 'Small line above the title', 'designer-designs' ) ),
		array( 'dd_hero_title', 'dd_s_hero', 'text', __( 'Title', 'designer-designs' ) ),
		array( 'dd_hero_lead', 'dd_s_hero', 'textarea', __( 'Intro text', 'designer-designs' ) ),
		array( 'dd_rating_override', 'dd_s_trust', 'text', __( 'Shop rating to show (leave empty to use website reviews)', 'designer-designs' ) ),
		array( 'dd_rating_count', 'dd_s_trust', 'number', __( 'Number of reviews', 'designer-designs' ) ),
		array( 'dd_rating_source', 'dd_s_trust', 'text', __( 'Where the rating comes from', 'designer-designs' ) ),
		array( 'dd_footer_about', 'dd_s_trust', 'textarea', __( 'Footer: about the studio', 'designer-designs' ) ),
		array( 'dd_instagram', 'dd_s_trust', 'url', __( 'Instagram link', 'designer-designs' ) ),
		array( 'dd_ga4_id', 'dd_s_track', 'text', __( 'Google Analytics 4 measurement ID (G-XXXXXXX)', 'designer-designs' ) ),
	);

	foreach ( $fields as $f ) {
		list( $key, $section, $type, $label ) = $f;
		$sanitize = 'sanitize_text_field';
		if ( 'textarea' === $type ) {
			$sanitize = 'sanitize_textarea_field';
		} elseif ( 'number' === $type ) {
			$sanitize = fn( $v ) => is_numeric( $v ) ? $v + 0 : 0;
		} elseif ( 'checkbox' === $type ) {
			$sanitize = fn( $v ) => (bool) $v;
		} elseif ( 'url' === $type ) {
			$sanitize = 'esc_url_raw';
		}
		$c->add_setting( $key, array( 'default' => $d[ $key ], 'sanitize_callback' => $sanitize ) );
		$c->add_control( $key, array( 'label' => $label, 'section' => $section, 'type' => $type ) );
	}
} );

// Make get_theme_mod() fall back to our defaults everywhere.
foreach ( array_keys( dd_defaults() ) as $dd_key ) {
	add_filter( 'theme_mod_' . $dd_key, function ( $value ) use ( $dd_key ) {
		if ( false === $value || null === $value ) {
			$d = dd_defaults();
			return $d[ $dd_key ];
		}
		return $value;
	} );
}
