<?php
/**
 * Small helpers shared by templates.
 *
 * @package designer-designs
 */

defined( 'ABSPATH' ) || exit;

/** Theme image URL. */
function dd_img( $file ) {
	return esc_url( DD_URI . '/assets/img/' . $file );
}

/** Free-delivery threshold in shop currency (Customizer, default 150). */
function dd_free_threshold() {
	return (float) get_theme_mod( 'dd_free_threshold', 150 );
}

/** Inline SVG icons (stroke = currentColor). */
function dd_icon( $name, $size = 22 ) {
	$paths = array(
		'search'  => '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
		'heart'   => '<path d="M12 20s-7-4.4-9.2-9A5 5 0 0 1 12 6a5 5 0 0 1 9.2 5c-2.2 4.6-9.2 9-9.2 9z"/>',
		'bag'     => '<path d="M5 8h14l-1 12H6L5 8z"/><path d="M9 8V6a3 3 0 0 1 6 0v2"/>',
		'user'    => '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
		'menu'    => '<path d="M4 7h16M4 12h16M4 17h16"/>',
		'close'   => '<path d="M6 6l12 12M18 6 6 18"/>',
		'plus'    => '<path d="M12 5v14M5 12h14"/>',
		'minus'   => '<path d="M5 12h14"/>',
		'left'    => '<path d="m15 6-6 6 6 6"/>',
		'right'   => '<path d="m9 6 6 6-6 6"/>',
		'arrow'   => '<path d="M5 12h14M13 6l6 6-6 6"/>',
		'lamp'    => '<path d="M8 3h8l3 8H5l3-8z"/><path d="M12 11v9M8 21h8"/>',
		'clock'   => '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
		'truck'   => '<path d="M3 6h11v10H3zM14 10h4l3 3v3h-7z"/><circle cx="7" cy="18" r="1.6"/><circle cx="17" cy="18" r="1.6"/>',
	);
	if ( ! isset( $paths[ $name ] ) ) {
		return '';
	}
	return sprintf(
		'<svg aria-hidden="true" focusable="false" width="%1$d" height="%1$d" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">%2$s</svg>',
		(int) $size,
		$paths[ $name ]
	);
}

/**
 * Top-level product categories for the navigation (Uncategorised is skipped).
 * Order follows the term meta "order" that WooCommerce uses for drag-and-drop sorting.
 *
 * @return WP_Term[]
 */
function dd_nav_categories() {
	static $cache = null;
	if ( null !== $cache ) {
		return $cache;
	}
	$terms = get_terms( array(
		'taxonomy'   => 'product_cat',
		'parent'     => 0,
		'hide_empty' => false,
		'orderby'    => 'meta_value_num',
		'meta_key'   => 'order', // phpcs:ignore WordPress.DB.SlowDBQuery
		'exclude'    => array( (int) get_option( 'default_product_cat' ) ),
	) );
	$cache = is_wp_error( $terms ) ? array() : $terms;
	return $cache;
}

/** Children of a category. */
function dd_sub_categories( $term_id ) {
	$terms = get_terms( array(
		'taxonomy'   => 'product_cat',
		'parent'     => (int) $term_id,
		'hide_empty' => false,
		'orderby'    => 'meta_value_num',
		'meta_key'   => 'order', // phpcs:ignore WordPress.DB.SlowDBQuery
	) );
	return is_wp_error( $terms ) ? array() : $terms;
}

/** A few products for a category, best sellers first. */
function dd_category_products( $slug, $limit = 4 ) {
	if ( ! function_exists( 'wc_get_products' ) ) {
		return array();
	}
	return wc_get_products( array(
		'status'   => 'publish',
		'limit'    => $limit,
		'category' => array( $slug ),
		'orderby'  => array( 'menu_order' => 'ASC', 'date' => 'DESC' ),
	) );
}

/** Category image URL (falls back to the first product image). */
function dd_category_image( $term, $size = 'dd-card' ) {
	$thumb = (int) get_term_meta( $term->term_id, 'thumbnail_id', true );
	if ( $thumb ) {
		return wp_get_attachment_image_url( $thumb, $size );
	}
	$products = dd_category_products( $term->slug, 1 );
	if ( $products && $products[0]->get_image_id() ) {
		return wp_get_attachment_image_url( $products[0]->get_image_id(), $size );
	}
	return dd_img( 'gold-vein-dark.jpg' );
}

/** Is this category flagged "coming soon" (term meta dd_soon = 1)? */
function dd_category_soon( $term ) {
	return (bool) get_term_meta( $term->term_id, 'dd_soon', true );
}

/** Short note shown under a category tile (term meta dd_note, else description). */
function dd_category_note( $term ) {
	$note = get_term_meta( $term->term_id, 'dd_note', true );
	return $note ? $note : wp_trim_words( wp_strip_all_tags( $term->description ), 6, '' );
}

/**
 * "Add a little extra" suggestions.
 * Order: cross-sells of the given products → products tagged "little-extra" → lowest priced in stock.
 *
 * @param int[] $for_ids  Products the suggestions are for.
 * @param int[] $exclude  Products to skip (already in basket).
 * @param int   $limit    How many.
 * @return WC_Product[]
 */
function dd_extras( $for_ids = array(), $exclude = array(), $limit = 3 ) {
	if ( ! function_exists( 'wc_get_product' ) ) {
		return array();
	}
	$ids = array();
	foreach ( (array) $for_ids as $id ) {
		$p = wc_get_product( $id );
		if ( $p ) {
			$parent = $p->get_parent_id() ? wc_get_product( $p->get_parent_id() ) : $p;
			$ids    = array_merge( $ids, $parent ? $parent->get_cross_sell_ids() : array() );
		}
	}
	$exclude = array_map( 'intval', (array) $exclude );
	$ids     = array_values( array_diff( array_unique( array_map( 'intval', $ids ) ), $exclude ) );

	if ( count( $ids ) < $limit ) {
		$tagged = wc_get_products( array( 'status' => 'publish', 'limit' => 8, 'tag' => array( 'little-extra' ), 'return' => 'ids', 'type' => array( 'simple' ) ) );
		$ids    = array_values( array_unique( array_merge( $ids, array_diff( $tagged, $exclude ) ) ) );
	}
	if ( count( $ids ) < $limit ) {
		$cheap = wc_get_products( array( 'status' => 'publish', 'limit' => 8, 'orderby' => 'price', 'order' => 'ASC', 'return' => 'ids', 'type' => array( 'simple' ) ) );
		$ids   = array_values( array_unique( array_merge( $ids, array_diff( $cheap, $exclude ) ) ) );
	}

	$out = array();
	foreach ( $ids as $id ) {
		$p = wc_get_product( $id );
		if ( $p && $p->is_purchasable() && $p->is_in_stock() && $p->is_visible() ) {
			$out[] = $p;
		}
		if ( count( $out ) >= $limit ) {
			break;
		}
	}
	return $out;
}

/** Render one small "extra" card with an AJAX add button. */
function dd_extra_card( WC_Product $p ) {
	$img = $p->get_image_id() ? wp_get_attachment_image_url( $p->get_image_id(), 'dd-card' ) : wc_placeholder_img_src();
	?>
	<div class="dd-extra">
		<a href="<?php echo esc_url( $p->get_permalink() ); ?>"><img src="<?php echo esc_url( $img ); ?>" alt="" loading="lazy" width="320" height="400"></a>
		<a href="<?php echo esc_url( $p->get_permalink() ); ?>" style="color:inherit;text-decoration:none"><?php echo esc_html( $p->get_name() ); ?></a>
		<span class="price"><?php echo wp_kses_post( $p->get_price_html() ); ?></span>
		<a href="<?php echo esc_url( $p->add_to_cart_url() ); ?>" data-quantity="1" data-product_id="<?php echo esc_attr( $p->get_id() ); ?>" data-product_sku="<?php echo esc_attr( $p->get_sku() ); ?>" class="button add_to_cart_button ajax_add_to_cart dd-extra__add" aria-label="<?php echo esc_attr( sprintf( __( 'Add %s to your basket', 'designer-designs' ), $p->get_name() ) ); ?>" rel="nofollow"><?php esc_html_e( 'Add', 'designer-designs' ); ?></a>
	</div>
	<?php
}

/** Average rating across all approved product reviews (for the "4.9" block). */
function dd_store_rating() {
	$override = trim( (string) dd_mod( 'dd_rating_override' ) );
	if ( '' !== $override ) {
		return array( (float) $override, (int) dd_mod( 'dd_rating_count' ), dd_mod( 'dd_rating_source' ) );
	}
	global $wpdb;
	$row = $wpdb->get_row( "SELECT AVG(m.meta_value) avg, COUNT(*) n FROM {$wpdb->comments} c JOIN {$wpdb->commentmeta} m ON m.comment_id=c.comment_ID AND m.meta_key='rating' WHERE c.comment_approved='1' AND c.comment_type='review'" ); // phpcs:ignore
	return array( $row && $row->n ? round( (float) $row->avg, 1 ) : 0, $row ? (int) $row->n : 0, '' );
}

/**
 * Footer/help links: the assigned menu, or the starter pages that exist.
 *
 * @param string $location Menu location.
 * @param bool   $inline   Bare links (mobile nav) instead of a list.
 */
function dd_footer_links( $location, $inline = false ) {
	$fallback = array(
		'footer-help'   => array( 'delivery' => 'Delivery & lead times', 'returns' => 'Returns', 'care' => 'Care guides', 'faq' => 'FAQ', 'contact' => 'Contact us' ),
		'footer-studio' => array( 'our-story' => 'Our story', 'materials' => 'Materials & process', 'commissions' => 'Custom commissions', 'trade' => 'Trade accounts', 'giving-back' => 'Giving back' ),
		'footer-legal'  => array( 'privacy-policy' => 'Privacy', 'terms' => 'Terms', 'cookies' => 'Cookies' ),
	);
	$links = array();
	$locs  = get_nav_menu_locations();
	if ( ! empty( $locs[ $location ] ) ) {
		foreach ( (array) wp_get_nav_menu_items( $locs[ $location ] ) as $item ) {
			$links[] = array( $item->url, $item->title );
		}
	} else {
		foreach ( $fallback[ $location ] ?? array() as $slug => $label ) {
			$page = get_page_by_path( $slug );
			if ( $page && 'publish' === $page->post_status ) {
				$links[] = array( get_permalink( $page ), __( $label, 'designer-designs' ) ); // phpcs:ignore WordPress.WP.I18n
			}
		}
	}
	if ( $inline ) {
		foreach ( $links as $l ) {
			printf( '<a href="%s">%s</a>', esc_url( $l[0] ), esc_html( $l[1] ) );
		}
		return;
	}
	echo '<ul>';
	foreach ( $links as $l ) {
		printf( '<li><a href="%s">%s</a></li>', esc_url( $l[0] ), esc_html( $l[1] ) );
	}
	echo '</ul>';
}
