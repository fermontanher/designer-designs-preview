<?php
/**
 * WooCommerce integration: wrappers, cards, basket drawer fragments,
 * product fields (lead time, materials, care) and colour swatch data.
 *
 * @package designer-designs
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'WooCommerce' ) ) {
	return;
}

/* ------------------------------------------------------------------ */
/* Layout wrappers                                                     */
/* ------------------------------------------------------------------ */
remove_action( 'woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10 );
remove_action( 'woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10 );
remove_action( 'woocommerce_sidebar', 'woocommerce_get_sidebar', 10 );

add_action( 'woocommerce_before_main_content', function () {
	echo '<main id="main" class="dd-wrap dd-shop">';
}, 10 );
add_action( 'woocommerce_after_main_content', function () {
	echo '</main>';
}, 10 );

add_filter( 'woocommerce_breadcrumb_defaults', function ( $args ) {
	$args['delimiter'] = '<span aria-hidden="true"> / </span>';
	$args['home']      = __( 'Home', 'designer-designs' );
	return $args;
} );

add_filter( 'loop_shop_per_page', fn() => 12 );
add_filter( 'woocommerce_output_related_products_args', function ( $args ) {
	$args['posts_per_page'] = 4;
	$args['columns']        = 4;
	return $args;
} );
add_filter( 'woocommerce_product_related_products_heading', fn() => __( 'Complete the look', 'designer-designs' ) );
add_filter( 'woocommerce_product_upsells_products_heading', fn() => __( 'You may also love', 'designer-designs' ) );

/* Sub-category chips above the product grid on category pages. */
add_action( 'woocommerce_archive_description', function () {
	if ( ! is_product_category() && ! is_shop() ) {
		return;
	}
	$current = get_queried_object();
	$parent  = ( $current instanceof WP_Term ) ? ( $current->parent ? $current->parent : $current->term_id ) : 0;
	$terms   = $parent ? dd_sub_categories( $parent ) : dd_nav_categories();
	if ( ! $terms ) {
		return;
	}
	echo '<nav class="dd-subcats" aria-label="' . esc_attr__( 'Categories', 'designer-designs' ) . '">';
	if ( $parent ) {
		$p = get_term( $parent, 'product_cat' );
		printf( '<a href="%s"%s>%s</a>', esc_url( get_term_link( $p ) ), ( $current->term_id === $p->term_id ) ? ' class="is-current" aria-current="page"' : '', esc_html( sprintf( __( 'All %s', 'designer-designs' ), strtolower( $p->name ) ) ) );
	}
	foreach ( $terms as $t ) {
		$is = ( $current instanceof WP_Term && $current->term_id === $t->term_id );
		printf( '<a href="%s"%s>%s</a>', esc_url( get_term_link( $t ) ), $is ? ' class="is-current" aria-current="page"' : '', esc_html( $t->name ) );
	}
	echo '</nav>';
}, 20 );

/* Loop "Add to basket" text and variable products. */
add_filter( 'woocommerce_product_add_to_cart_text', function ( $text, $product ) {
	if ( $product->is_type( 'variable' ) ) {
		return __( 'Choose size and colour', 'designer-designs' );
	}
	if ( $product->is_type( 'simple' ) && $product->is_purchasable() && $product->is_in_stock() ) {
		return __( 'Add to basket', 'designer-designs' );
	}
	return $text;
}, 10, 2 );
add_filter( 'woocommerce_product_single_add_to_cart_text', fn() => __( 'Add to basket', 'designer-designs' ) );

/* Show "From £x" for variable products instead of a range. */
add_filter( 'woocommerce_variable_price_html', function ( $price, $product ) {
	$min = $product->get_variation_price( 'min', true );
	$max = $product->get_variation_price( 'max', true );
	if ( $min !== $max ) {
		/* translators: %s: lowest price */
		return sprintf( __( 'From %s', 'designer-designs' ), wc_price( $min ) );
	}
	return $price;
}, 10, 2 );

/* Never redirect to the cart after adding; the drawer opens instead. */
add_filter( 'pre_option_woocommerce_cart_redirect_after_add', fn() => 'no' );
add_filter( 'pre_option_woocommerce_enable_ajax_add_to_cart', fn() => 'yes' );

/* ------------------------------------------------------------------ */
/* Basket drawer + fragments                                           */
/* ------------------------------------------------------------------ */

/** Free delivery progress block. */
function dd_ship_html() {
	$threshold = dd_free_threshold();
	$sub       = WC()->cart ? (float) WC()->cart->get_displayed_subtotal() : 0;
	$left      = max( 0, $threshold - $sub );
	$pct       = $threshold > 0 ? min( 100, round( $sub / $threshold * 100 ) ) : 100;
	ob_start();
	?>
	<div class="dd-ship" id="dd-ship" role="status">
		<span>
		<?php
		if ( $sub <= 0 ) {
			/* translators: %s: amount */
			printf( esc_html__( 'Free UK delivery on orders over %s.', 'designer-designs' ), wp_kses_post( wc_price( $threshold, array( 'decimals' => 0 ) ) ) );
		} elseif ( $left > 0 ) {
			/* translators: %s: amount left */
			printf( esc_html__( 'You are %s away from free UK delivery.', 'designer-designs' ), '<strong>' . wp_kses_post( wc_price( $left ) ) . '</strong>' );
		} else {
			esc_html_e( 'Your order ships free in the UK.', 'designer-designs' );
		}
		?>
		</span>
		<span class="dd-ship__bar" aria-hidden="true"><span style="width:<?php echo esc_attr( $pct ); ?>%"></span></span>
	</div>
	<?php
	return ob_get_clean();
}

/** Drawer body: line items + extras. */
function dd_drawer_body_html() {
	ob_start();
	echo '<div class="dd-drawer__body" id="dd-drawer-body"><div class="dd-mini">';
	woocommerce_mini_cart();
	echo '</div>';

	$in_cart = array();
	$for     = array();
	if ( WC()->cart ) {
		foreach ( WC()->cart->get_cart() as $item ) {
			$in_cart[] = (int) $item['product_id'];
			$for[]     = (int) $item['product_id'];
		}
	}
	$extras = dd_extras( $for, $in_cart, 3 );
	if ( $extras ) {
		echo '<div class="dd-extras"><h3>' . esc_html__( 'Add a little extra', 'designer-designs' ) . '</h3><div class="dd-extras__grid">';
		foreach ( $extras as $p ) {
			dd_extra_card( $p );
		}
		echo '</div></div>';
	}
	echo '</div>';
	return ob_get_clean();
}

/** Drawer footer: subtotal, Klarna line, checkout. */
function dd_drawer_foot_html() {
	$count = WC()->cart ? WC()->cart->get_cart_contents_count() : 0;
	$sub   = WC()->cart ? (float) WC()->cart->get_displayed_subtotal() : 0;
	ob_start();
	?>
	<div class="dd-drawer__foot" id="dd-drawer-foot" <?php echo $count ? '' : 'hidden'; ?>>
		<div class="dd-total"><span><?php esc_html_e( 'Subtotal', 'designer-designs' ); ?></span><strong><?php echo wp_kses_post( wc_price( $sub ) ); ?></strong></div>
		<?php if ( dd_mod( 'dd_klarna' ) && $sub > 0 ) : ?>
			<span class="dd-muted" style="font-size:13px"><?php printf( esc_html__( 'or 3 interest-free payments of %s with Klarna', 'designer-designs' ), wp_kses_post( wc_price( $sub / 3 ) ) ); ?></span>
		<?php endif; ?>
		<a class="dd-btn dd-btn--gold dd-btn--block" href="<?php echo esc_url( wc_get_checkout_url() ); ?>"><?php esc_html_e( 'Checkout securely', 'designer-designs' ); ?></a>
		<a class="dd-link" style="text-align:center" href="<?php echo esc_url( wc_get_cart_url() ); ?>"><?php esc_html_e( 'View basket', 'designer-designs' ); ?></a>
	</div>
	<?php
	return ob_get_clean();
}

add_filter( 'woocommerce_add_to_cart_fragments', function ( $fragments ) {
	$count                       = WC()->cart->get_cart_contents_count();
	$fragments['span.dd-count']  = '<span class="dd-count" data-count="' . esc_attr( $count ) . '">' . ( $count ? esc_html( $count ) : '' ) . '</span>';
	$fragments['#dd-ship']       = dd_ship_html();
	$fragments['#dd-drawer-body'] = dd_drawer_body_html();
	$fragments['#dd-drawer-foot'] = dd_drawer_foot_html();
	return $fragments;
} );

add_filter( 'woocommerce_cart_item_remove_link', function ( $link ) {
	return str_replace( '&times;', '<span aria-hidden="true">&times;</span>', $link );
} );

/* ------------------------------------------------------------------ */
/* Product fields: lead time, materials, care, delivery                */
/* ------------------------------------------------------------------ */
add_filter( 'woocommerce_product_data_tabs', function ( $tabs ) {
	$tabs['dd_details'] = array(
		'label'    => __( 'Designer Designs', 'designer-designs' ),
		'target'   => 'dd_details_panel',
		'priority' => 15,
	);
	return $tabs;
} );

function dd_product_fields() {
	return array(
		'_dd_kicker'    => array( __( 'Small line above the name (e.g. "Floor lamp, handmade in London")', 'designer-designs' ), 'text' ),
		'_dd_lead_time' => array( __( 'Lead time (e.g. "Made to order: ships in 3 to 4 weeks")', 'designer-designs' ), 'text' ),
		'_dd_materials' => array( __( 'Materials and finish', 'designer-designs' ), 'textarea' ),
		'_dd_care'      => array( __( 'Care, and what is in the box', 'designer-designs' ), 'textarea' ),
		'_dd_delivery'  => array( __( 'Delivery and returns (leave empty to use the shop default)', 'designer-designs' ), 'textarea' ),
		'_dd_story'     => array( __( 'Story paragraph under the photos', 'designer-designs' ), 'textarea' ),
	);
}

add_action( 'woocommerce_product_data_panels', function () {
	echo '<div id="dd_details_panel" class="panel woocommerce_options_panel"><div class="options_group">';
	foreach ( dd_product_fields() as $key => $f ) {
		$args = array( 'id' => $key, 'label' => $f[0] );
		if ( 'textarea' === $f[1] ) {
			woocommerce_wp_textarea_input( $args + array( 'rows' => 4 ) );
		} else {
			woocommerce_wp_text_input( $args );
		}
	}
	echo '</div></div>';
} );

add_action( 'woocommerce_admin_process_product_object', function ( WC_Product $product ) {
	foreach ( dd_product_fields() as $key => $f ) {
		if ( isset( $_POST[ $key ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			$val = 'textarea' === $f[1] ? sanitize_textarea_field( wp_unslash( $_POST[ $key ] ) ) : sanitize_text_field( wp_unslash( $_POST[ $key ] ) ); // phpcs:ignore
			$product->update_meta_data( $key, $val );
		}
	}
} );

/* ------------------------------------------------------------------ */
/* Colour swatches: hex code on pa_colour terms                        */
/* ------------------------------------------------------------------ */
add_action( 'pa_colour_add_form_fields', function () {
	echo '<div class="form-field"><label for="dd_hex">' . esc_html__( 'Swatch colour', 'designer-designs' ) . '</label><input type="color" name="dd_hex" id="dd_hex" value="#242424"></div>';
} );
add_action( 'pa_colour_edit_form_fields', function ( $term ) {
	$hex = get_term_meta( $term->term_id, 'dd_hex', true ) ?: '#242424';
	echo '<tr class="form-field"><th><label for="dd_hex">' . esc_html__( 'Swatch colour', 'designer-designs' ) . '</label></th><td><input type="color" name="dd_hex" id="dd_hex" value="' . esc_attr( $hex ) . '"></td></tr>';
} );
foreach ( array( 'created_pa_colour', 'edited_pa_colour' ) as $dd_hook ) {
	add_action( $dd_hook, function ( $term_id ) {
		if ( isset( $_POST['dd_hex'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			update_term_meta( $term_id, 'dd_hex', sanitize_hex_color( wp_unslash( $_POST['dd_hex'] ) ) ); // phpcs:ignore
		}
	} );
}

/**
 * Data for the swatch script: colour hex codes and size dimensions (size term description).
 */
function dd_swatch_data( WC_Product $product ) {
	$out = array();
	if ( ! $product->is_type( 'variable' ) ) {
		return $out;
	}
	foreach ( $product->get_variation_attributes() as $attr => $options ) {
		$key = 'attribute_' . sanitize_title( $attr );
		foreach ( $options as $slug ) {
			$entry = array( 'label' => $slug );
			if ( taxonomy_exists( $attr ) ) {
				$term = get_term_by( 'slug', $slug, $attr );
				if ( $term ) {
					$entry['label'] = $term->name;
					$hex            = get_term_meta( $term->term_id, 'dd_hex', true );
					if ( $hex ) {
						$entry['hex'] = $hex;
					}
					if ( $term->description ) {
						$entry['note'] = wp_strip_all_tags( $term->description );
					}
				}
			}
			$out[ $key ][ $slug ] = $entry;
		}
	}
	// Lowest price per size option, so each size button can show its price.
	foreach ( $product->get_available_variations( 'objects' ) as $v ) {
		foreach ( $v->get_attributes() as $a => $val ) {
			$k = 'attribute_' . $a;
			if ( isset( $out[ $k ][ $val ] ) && ( false !== strpos( $a, 'size' ) ) ) {
				$p = (float) wc_get_price_to_display( $v );
				if ( ! isset( $out[ $k ][ $val ]['min'] ) || $p < $out[ $k ][ $val ]['min'] ) {
					$out[ $k ][ $val ]['min']      = $p;
					$out[ $k ][ $val ]['minLabel'] = wp_strip_all_tags( wc_price( $p, array( 'decimals' => 0 ) ) );
				}
			}
		}
	}
	return $out;
}

/* Hide the default "Clear" link text, keep the function. */
add_filter( 'woocommerce_reset_variations_link', fn() => '<a class="reset_variations" href="#">' . esc_html__( 'Clear selection', 'designer-designs' ) . '</a>' );

/* Reviews: keep the form simple. */
add_filter( 'woocommerce_product_review_comment_form_args', function ( $args ) {
	$args['title_reply'] = __( 'Write a review', 'designer-designs' );
	return $args;
} );
