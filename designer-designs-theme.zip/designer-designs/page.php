<?php
/**
 * Pages (story, delivery, care, contact…). Cart and checkout pages use their blocks full width.
 *
 * @package designer-designs
 */

get_header();
$dd_wide = function_exists( 'is_cart' ) && ( is_cart() || is_checkout() || is_account_page() );
while ( have_posts() ) :
	the_post();
	?>
	<main id="main" class="dd-wrap dd-page">
		<h1 class="dd-page__title"><?php the_title(); ?></h1>
		<div class="<?php echo $dd_wide ? 'dd-wc-page' : 'dd-prose'; ?>">
			<?php the_content(); ?>
		</div>
	</main>
	<?php
endwhile;
get_footer();
