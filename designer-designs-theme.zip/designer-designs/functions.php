<?php
/**
 * Designer Designs theme functions.
 *
 * @package designer-designs
 */

defined( 'ABSPATH' ) || exit;

define( 'DD_VERSION', '0.5.0' );
define( 'DD_URI', get_template_directory_uri() );
define( 'DD_DIR', get_template_directory() );

require DD_DIR . '/inc/helpers.php';
require DD_DIR . '/inc/customizer.php';
require DD_DIR . '/inc/woocommerce.php';

/* ------------------------------------------------------------------ */
/* Setup                                                               */
/* ------------------------------------------------------------------ */
add_action( 'after_setup_theme', function () {
	load_theme_textdomain( 'designer-designs', DD_DIR . '/languages' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script', 'navigation-widgets' ) );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'custom-logo', array( 'height' => 92, 'width' => 280, 'flex-width' => true, 'flex-height' => true ) );

	add_theme_support( 'woocommerce', array(
		'thumbnail_image_width' => 640,
		'single_image_width'    => 1200,
		'product_grid'          => array( 'default_columns' => 4, 'default_rows' => 3 ),
	) );

	add_image_size( 'dd-card', 640, 800, true );
	add_image_size( 'dd-thumb', 168, 210, true );
	add_image_size( 'dd-large', 1400, 1750, true );

	register_nav_menus( array(
		'footer-help'   => __( 'Footer: Help', 'designer-designs' ),
		'footer-studio' => __( 'Footer: Studio', 'designer-designs' ),
		'footer-legal'  => __( 'Footer: Legal', 'designer-designs' ),
	) );
} );

/* ------------------------------------------------------------------ */
/* Assets                                                              */
/* ------------------------------------------------------------------ */
add_action( 'wp_enqueue_scripts', function () {
	wp_enqueue_style( 'designer-designs', get_stylesheet_uri(), array(), DD_VERSION );

	// WooCommerce layout styles fight the custom grid; keep the general ones (icons, notices).
	wp_dequeue_style( 'woocommerce-layout' );
	wp_dequeue_style( 'woocommerce-smallscreen' );

	if ( class_exists( 'WooCommerce' ) ) {
		wp_enqueue_script( 'wc-add-to-cart' );
		wp_enqueue_script( 'wc-cart-fragments' );
	}
	wp_enqueue_script( 'designer-designs', DD_URI . '/assets/js/theme.js', array( 'jquery' ), DD_VERSION, array( 'in_footer' => true, 'strategy' => 'defer' ) );
	wp_localize_script( 'designer-designs', 'DD', array(
		'freeThreshold' => dd_free_threshold(),
		'currency'      => function_exists( 'get_woocommerce_currency_symbol' ) ? html_entity_decode( get_woocommerce_currency_symbol() ) : '£',
		'klarna'        => (bool) get_theme_mod( 'dd_klarna', true ),
		'offerDelay'    => (int) get_theme_mod( 'dd_offer_delay', 12 ),
		'offerOn'       => (bool) get_theme_mod( 'dd_offer_on', true ),
		'i18n'          => array(
			'added'      => __( 'added to your basket', 'designer-designs' ),
			'add'        => __( 'Add', 'designer-designs' ),
			'addedShort' => __( 'Added', 'designer-designs' ),
			'lampOn'     => __( 'Switch the lamp on', 'designer-designs' ),
			'lampOff'    => __( 'Switch the lamp off', 'designer-designs' ),
			'klarna'     => __( 'or 3 interest-free payments of %s with Klarna', 'designer-designs' ),
			'choose'     => __( 'Choose a size and colour', 'designer-designs' ),
		),
	) );
} );

add_action( 'wp_head', function () {
	// Preload the two fonts used above the fold.
	printf( '<link rel="preload" href="%s" as="font" type="font/woff2" crossorigin>' . "\n", esc_url( DD_URI . '/assets/fonts/gentium-italic.woff2' ) );
	printf( '<link rel="preload" href="%s" as="font" type="font/woff2" crossorigin>' . "\n", esc_url( DD_URI . '/assets/fonts/raleway-variable.woff2' ) );
	echo '<meta name="theme-color" content="#000000">' . "\n";
}, 1 );

/* ------------------------------------------------------------------ */
/* Analytics (milestone 4): GA4 measurement ID set in the Customizer   */
/* ------------------------------------------------------------------ */
add_action( 'wp_head', function () {
	$id = trim( (string) get_theme_mod( 'dd_ga4_id', '' ) );
	if ( ! $id || is_user_logged_in() && current_user_can( 'manage_options' ) ) {
		return;
	}
	?>
<script async src="https://www.googletagmanager.com/gtag/js?id=<?php echo esc_attr( $id ); ?>"></script>
<script>window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}gtag('js',new Date());gtag('config','<?php echo esc_js( $id ); ?>');</script>
	<?php
}, 5 );

/* Body classes */
add_filter( 'body_class', function ( $classes ) {
	$classes[] = 'dd';
	return $classes;
} );

/* Excerpt length for short descriptions in cards */
add_filter( 'excerpt_length', fn() => 24 );

/* ------------------------------------------------------------------ */
/* Newsletter sign-ups (stored locally until a mail service is chosen) */
/* ------------------------------------------------------------------ */
function dd_handle_subscribe() {
	$back = wp_get_referer() ? wp_get_referer() : home_url( '/' );
	if ( ! isset( $_POST['dd_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['dd_nonce'] ), 'dd_subscribe' ) ) {
		wp_safe_redirect( $back );
		exit;
	}
	$email = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
	if ( is_email( $email ) ) {
		$list           = (array) get_option( 'dd_subscribers', array() );
		$list[ $email ] = current_time( 'mysql' );
		update_option( 'dd_subscribers', $list, false );
	}
	wp_safe_redirect( add_query_arg( 'subscribed', 'yes', $back ) . '#dd-news-email' );
	exit;
}
add_action( 'admin_post_nopriv_dd_subscribe', 'dd_handle_subscribe' );
add_action( 'admin_post_dd_subscribe', 'dd_handle_subscribe' );

add_action( 'admin_menu', function () {
	add_submenu_page( 'woocommerce', __( 'Newsletter sign-ups', 'designer-designs' ), __( 'Newsletter sign-ups', 'designer-designs' ), 'manage_woocommerce', 'dd-subscribers', function () {
		$list = (array) get_option( 'dd_subscribers', array() );
		echo '<div class="wrap"><h1>' . esc_html__( 'Newsletter sign-ups', 'designer-designs' ) . '</h1>';
		echo '<p>' . esc_html__( 'Copy these into your email tool (Mailchimp, Klaviyo…).', 'designer-designs' ) . '</p>';
		echo '<textarea readonly rows="12" style="width:100%;max-width:640px">' . esc_textarea( implode( "\n", array_keys( $list ) ) ) . '</textarea>';
		echo '<p>' . esc_html( sprintf( _n( '%d person', '%d people', count( $list ), 'designer-designs' ), count( $list ) ) ) . '</p></div>';
	} );
} );
