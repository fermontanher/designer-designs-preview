<?php
/**
 * Footer: brand and help information live here (navigation stays products-only),
 * plus the basket drawer, the free-delivery pop-up and the toast.
 *
 * @package designer-designs
 */

defined( 'ABSPATH' ) || exit;
$dd_sub = isset( $_GET['subscribed'] ) ? sanitize_key( $_GET['subscribed'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
?>
<footer class="dd-footer">
	<?php /* Newsletter band (Cox & Cox puts sign-up first in the footer). */ ?>
	<div class="dd-wrap dd-footer__news">
		<div class="dd-footer__news-copy">
			<h2 class="dd-serif"><?php esc_html_e( 'New pieces, once a month', 'designer-designs' ); ?></h2>
			<p><?php echo esc_html( dd_mod( 'dd_newsletter_text' ) ); ?></p>
		</div>
		<form class="dd-news" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<?php if ( 'yes' === $dd_sub ) : ?>
				<p role="status" style="color:var(--dd-gold-text)"><?php esc_html_e( 'Thank you. You are on the list.', 'designer-designs' ); ?></p>
			<?php else : ?>
				<label for="dd-news-email"><?php esc_html_e( 'Email address', 'designer-designs' ); ?></label>
				<div class="dd-news__row">
					<input class="dd-field" id="dd-news-email" type="email" name="email" required autocomplete="email" placeholder="you@example.com">
					<button class="dd-btn" type="submit"><?php esc_html_e( 'Subscribe', 'designer-designs' ); ?></button>
				</div>
				<input type="hidden" name="action" value="dd_subscribe">
				<?php wp_nonce_field( 'dd_subscribe', 'dd_nonce' ); ?>
			<?php endif; ?>
		</form>
	</div>

	<div class="dd-wrap dd-footer__top">
		<?php /* The atelier: brand + a real contact block (from monoaurel). */ ?>
		<div class="dd-footer__brand">
			<img src="<?php echo dd_img( 'logo-primary-gold.png' ); // phpcs:ignore ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" width="220" height="140" loading="lazy">
			<p><?php echo esc_html( dd_mod( 'dd_footer_about' ) ); ?></p>
			<address class="dd-footer__contact">
				<?php $dd_email = dd_mod( 'dd_email' ); ?>
				<?php if ( $dd_email && is_email( $dd_email ) ) : ?>
					<a class="dd-footer__email" href="mailto:<?php echo esc_attr( antispambot( $dd_email ) ); ?>"><?php echo esc_html( antispambot( $dd_email ) ); ?></a>
				<?php else : ?>
					<span class="dd-footer__email">[studio email]</span>
				<?php endif; ?>
				<span><?php echo esc_html( dd_mod( 'dd_reply_note' ) ); ?></span>
				<?php $dd_phone = dd_mod( 'dd_phone' ); ?>
				<?php if ( $dd_phone ) : ?>
					<a href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', $dd_phone ) ); ?>"><?php echo esc_html( $dd_phone ); ?></a>
					<span><?php echo esc_html( dd_mod( 'dd_hours' ) ); ?></span>
				<?php endif; ?>
				<span><?php echo esc_html( dd_mod( 'dd_location' ) ); ?></span>
			</address>
			<?php echo dd_social_links(); // phpcs:ignore -- escaped inside. ?>
		</div>

		<nav aria-labelledby="dd-f-shop">
			<h2 id="dd-f-shop"><?php esc_html_e( 'Shop', 'designer-designs' ); ?></h2>
			<ul>
				<?php foreach ( dd_nav_categories() as $dd_cat ) : ?>
					<li><a href="<?php echo esc_url( get_term_link( $dd_cat ) ); ?>"><?php echo esc_html( $dd_cat->name ); ?></a></li>
				<?php endforeach; ?>
				<?php if ( function_exists( 'wc_get_page_permalink' ) ) : ?>
					<li><a href="<?php echo esc_url( wc_get_page_permalink( 'shop' ) ); ?>"><?php esc_html_e( 'All pieces', 'designer-designs' ); ?></a></li>
				<?php endif; ?>
			</ul>
		</nav>

		<nav aria-labelledby="dd-f-help">
			<h2 id="dd-f-help"><?php esc_html_e( 'How can we help?', 'designer-designs' ); ?></h2>
			<?php
			$dd_track = array();
			if ( function_exists( 'wc_get_account_endpoint_url' ) ) {
				$dd_track[] = array( wc_get_account_endpoint_url( 'orders' ), __( "Where's my order?", 'designer-designs' ) );
			}
			dd_footer_links( 'footer-help', false, $dd_track );
			?>
		</nav>

		<nav aria-labelledby="dd-f-account">
			<h2 id="dd-f-account"><?php esc_html_e( 'Your account', 'designer-designs' ); ?></h2>
			<?php
			$dd_acc = array();
			if ( function_exists( 'wc_get_page_permalink' ) ) {
				$dd_acc_url = wc_get_page_permalink( 'myaccount' );
				if ( is_user_logged_in() ) {
					$dd_acc[] = array( $dd_acc_url, __( 'My account', 'designer-designs' ) );
				} else {
					$dd_acc[] = array( $dd_acc_url, __( 'Sign in', 'designer-designs' ) );
					if ( 'yes' === get_option( 'woocommerce_enable_myaccount_registration' ) ) {
						$dd_acc[] = array( $dd_acc_url, __( 'Create an account', 'designer-designs' ) );
					}
				}
			}
			$dd_acc[] = array( '#dd-news-email', __( 'Email sign-up', 'designer-designs' ) );
			dd_footer_links( 'footer-account', false, $dd_acc );
			?>
		</nav>

		<nav aria-labelledby="dd-f-studio">
			<h2 id="dd-f-studio"><?php esc_html_e( 'The studio', 'designer-designs' ); ?></h2>
			<?php dd_footer_links( 'footer-studio' ); ?>
		</nav>
	</div>

	<div class="dd-wrap dd-footer__bottom">
		<span>© <?php echo esc_html( gmdate( 'Y' ) ); ?> <?php esc_html_e( 'Designer Designs Studio, London', 'designer-designs' ); ?></span>
		<ul class="dd-pay" aria-label="<?php esc_attr_e( 'Ways to pay', 'designer-designs' ); ?>">
			<?php foreach ( array( 'Visa', 'Mastercard', 'Amex', 'PayPal', 'Apple Pay', 'Google Pay', 'Klarna' ) as $dd_pay ) : ?>
				<li><?php echo esc_html( $dd_pay ); ?></li>
			<?php endforeach; ?>
		</ul>
		<span class="dd-footer__legal"><?php dd_footer_links( 'footer-legal', true ); ?></span>
	</div>
</footer>

<?php if ( function_exists( 'WC' ) && ! is_cart() && ! is_checkout() ) : ?>
<div class="dd-drawer" id="dd-drawer" data-dd-drawer aria-hidden="true">
	<button type="button" class="dd-drawer__scrim" data-dd-drawer-close tabindex="-1" aria-label="<?php esc_attr_e( 'Close basket', 'designer-designs' ); ?>"></button>
	<aside class="dd-drawer__panel" role="dialog" aria-modal="true" aria-labelledby="dd-drawer-title">
		<div class="dd-drawer__head">
			<h2 id="dd-drawer-title"><?php esc_html_e( 'Your basket', 'designer-designs' ); ?></h2>
			<button type="button" class="dd-icon-btn" data-dd-drawer-close aria-label="<?php esc_attr_e( 'Close basket', 'designer-designs' ); ?>"><?php echo dd_icon( 'close' ); // phpcs:ignore ?></button>
		</div>
		<?php
		echo dd_ship_html(); // phpcs:ignore
		echo dd_drawer_body_html(); // phpcs:ignore
		echo dd_drawer_foot_html(); // phpcs:ignore
		?>
	</aside>
</div>
<?php endif; ?>

<?php if ( dd_mod( 'dd_offer_on' ) && ! ( function_exists( 'is_checkout' ) && ( is_checkout() || is_cart() ) ) ) : ?>
<div class="dd-offer" data-dd-offer role="dialog" aria-labelledby="dd-offer-title" aria-modal="false">
	<button type="button" class="dd-icon-btn" data-dd-offer-close aria-label="<?php esc_attr_e( 'Close', 'designer-designs' ); ?>"><?php echo dd_icon( 'close', 18 ); // phpcs:ignore ?></button>
	<strong id="dd-offer-title" class="dd-foil-text"><?php echo esc_html( dd_mod( 'dd_offer_title' ) ); ?></strong>
	<p><?php echo esc_html( dd_mod( 'dd_offer_text' ) ); ?></p>
	<?php if ( function_exists( 'wc_get_page_permalink' ) ) : ?>
		<a class="dd-btn dd-btn--gold" href="<?php echo esc_url( wc_get_page_permalink( 'shop' ) ); ?>" data-dd-offer-close style="align-self:flex-start;min-height:46px"><?php esc_html_e( 'Start shopping', 'designer-designs' ); ?></a>
	<?php endif; ?>
</div>
<?php endif; ?>

<div class="dd-toast" data-dd-toast role="status" aria-live="polite"></div>

<?php wp_footer(); ?>
</body>
</html>
