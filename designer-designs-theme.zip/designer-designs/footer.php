<?php
/**
 * Footer: brand and help information live here (navigation stays products-only),
 * plus the basket drawer, the free-delivery pop-up and the toast.
 *
 * @package designer-designs
 */

defined( 'ABSPATH' ) || exit;
$dd_sub = isset( $_GET['subscribed'] ) ? sanitize_key( $_GET['subscribed'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
?>
<footer class="dd-footer">
	<div class="dd-wrap dd-footer__top">
		<div class="dd-footer__brand">
			<img src="<?php echo dd_img( 'logo-primary-gold.png' ); // phpcs:ignore ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" width="220" height="140" loading="lazy">
			<p><?php echo esc_html( dd_mod( 'dd_footer_about' ) ); ?></p>
			<?php $dd_story = get_page_by_path( 'our-story' ); ?>
			<?php if ( $dd_story ) : ?>
				<a href="<?php echo esc_url( get_permalink( $dd_story ) ); ?>" style="font-weight:500"><?php esc_html_e( 'Read our story', 'designer-designs' ); ?></a>
			<?php endif; ?>
		</div>

		<nav aria-labelledby="dd-f-shop">
			<h2 id="dd-f-shop"><?php esc_html_e( 'Shop', 'designer-designs' ); ?></h2>
			<ul>
				<?php foreach ( dd_nav_categories() as $dd_cat ) : ?>
					<li><a href="<?php echo esc_url( get_term_link( $dd_cat ) ); ?>"><?php echo esc_html( $dd_cat->name ); ?></a></li>
				<?php endforeach; ?>
			</ul>
		</nav>
		<nav aria-labelledby="dd-f-help">
			<h2 id="dd-f-help"><?php esc_html_e( 'Help', 'designer-designs' ); ?></h2>
			<?php dd_footer_links( 'footer-help' ); ?>
		</nav>
		<nav aria-labelledby="dd-f-studio">
			<h2 id="dd-f-studio"><?php esc_html_e( 'Studio', 'designer-designs' ); ?></h2>
			<?php dd_footer_links( 'footer-studio' ); ?>
		</nav>

		<form class="dd-news" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<strong class="dd-serif" style="font-size:24px;font-weight:400"><?php esc_html_e( 'New pieces, once a month', 'designer-designs' ); ?></strong>
			<?php if ( 'yes' === $dd_sub ) : ?>
				<p role="status" style="color:var(--dd-gold-text)"><?php esc_html_e( 'Thank you. You are on the list.', 'designer-designs' ); ?></p>
			<?php else : ?>
				<label for="dd-news-email"><?php esc_html_e( 'Email address', 'designer-designs' ); ?></label>
				<input class="dd-field" id="dd-news-email" type="email" name="email" required autocomplete="email" placeholder="you@example.com">
				<input type="hidden" name="action" value="dd_subscribe">
				<?php wp_nonce_field( 'dd_subscribe', 'dd_nonce' ); ?>
				<button class="dd-btn" type="submit"><?php esc_html_e( 'Subscribe', 'designer-designs' ); ?></button>
			<?php endif; ?>
			<?php if ( dd_mod( 'dd_instagram' ) ) : ?>
				<a href="<?php echo esc_url( dd_mod( 'dd_instagram' ) ); ?>" rel="noopener" target="_blank" style="font-size:14px"><?php esc_html_e( 'Follow the studio on Instagram', 'designer-designs' ); ?></a>
			<?php endif; ?>
		</form>
	</div>

	<div class="dd-wrap dd-footer__bottom">
		<span>© <?php echo esc_html( gmdate( 'Y' ) ); ?> <?php esc_html_e( 'Designer Designs Studio, London', 'designer-designs' ); ?></span>
		<span><?php esc_html_e( 'Visa, Mastercard, Amex, PayPal, Apple Pay, Klarna', 'designer-designs' ); ?></span>
		<span style="display:flex;gap:16px"><?php dd_footer_links( 'footer-legal', true ); ?></span>
	</div>
</footer>

<?php if ( function_exists( 'WC' ) && ! is_cart() && ! is_checkout() ) : ?>
<div class="dd-drawer" id="dd-drawer" data-dd-drawer aria-hidden="true">
	<button type="button" class="dd-drawer__scrim" data-dd-drawer-close tabindex="-1" aria-label="<?php esc_attr_e( 'Close basket', 'designer-designs' ); ?>"></button>
	<aside class="dd-drawer__panel" role="dialog" aria-modal="true" aria-labelledby="dd-drawer-title">
		<div class="dd-drawer__head">
			<h2 id="dd-drawer-title"><?php esc_html_e( 'Your basket', 'designer-designs' ); ?></h2>
			<button type="button" class="dd-icon-btn" data-dd-drawer-close aria-label="<?php esc_attr_e( 'Close basket', 'designer-designs' ); ?>"><?php echo dd_icon( 'close' ); // phpcs:ignore ?></button>
		</div>
		<?php
		echo dd_ship_html(); // phpcs:ignore
		echo dd_drawer_body_html(); // phpcs:ignore
		echo dd_drawer_foot_html(); // phpcs:ignore
		?>
	</aside>
</div>
<?php endif; ?>

<?php if ( dd_mod( 'dd_offer_on' ) && ! ( function_exists( 'is_checkout' ) && ( is_checkout() || is_cart() ) ) ) : ?>
<div class="dd-offer" data-dd-offer role="dialog" aria-labelledby="dd-offer-title" aria-modal="false">
	<button type="button" class="dd-icon-btn" data-dd-offer-close aria-label="<?php esc_attr_e( 'Close', 'designer-designs' ); ?>"><?php echo dd_icon( 'close', 18 ); // phpcs:ignore ?></button>
	<strong id="dd-offer-title" class="dd-foil-text"><?php echo esc_html( dd_mod( 'dd_offer_title' ) ); ?></strong>
	<p><?php echo esc_html( dd_mod( 'dd_offer_text' ) ); ?></p>
	<?php if ( function_exists( 'wc_get_page_permalink' ) ) : ?>
		<a class="dd-btn dd-btn--gold" href="<?php echo esc_url( wc_get_page_permalink( 'shop' ) ); ?>" data-dd-offer-close style="align-self:flex-start;min-height:46px"><?php esc_html_e( 'Start shopping', 'designer-designs' ); ?></a>
	<?php endif; ?>
</div>
<?php endif; ?>

<div class="dd-toast" data-dd-toast role="status" aria-live="polite"></div>

<?php wp_footer(); ?>
</body>
</html>
