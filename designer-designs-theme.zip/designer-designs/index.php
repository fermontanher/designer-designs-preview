<?php
/**
 * Fallback template (blog, search, archives).
 *
 * @package designer-designs
 */

get_header();
?>
<main id="main" class="dd-wrap dd-page">
	<h1 class="dd-page__title">
		<?php
		if ( is_search() ) {
			/* translators: %s: search term */
			printf( esc_html__( 'Results for “%s”', 'designer-designs' ), esc_html( get_search_query() ) );
		} elseif ( is_archive() ) {
			echo wp_kses_post( get_the_archive_title() );
		} else {
			esc_html_e( 'Journal', 'designer-designs' );
		}
		?>
	</h1>
	<?php if ( have_posts() ) : ?>
		<div class="dd-products" style="grid-template-columns:repeat(auto-fill,minmax(min(300px,100%),1fr))">
			<?php
			while ( have_posts() ) :
				the_post();
				?>
				<article <?php post_class( 'dd-mega__item' ); ?>>
					<a href="<?php the_permalink(); ?>" style="color:inherit;text-decoration:none;display:flex;flex-direction:column;gap:12px">
						<?php if ( has_post_thumbnail() ) { the_post_thumbnail( 'dd-card' ); } ?>
						<span class="name"><?php the_title(); ?></span>
					</a>
					<p class="dd-muted"><?php echo esc_html( get_the_excerpt() ); ?></p>
				</article>
			<?php endwhile; ?>
		</div>
		<div style="margin-top:48px"><?php the_posts_pagination(); ?></div>
	<?php else : ?>
		<p class="dd-muted"><?php esc_html_e( 'Nothing found. Try the shop categories above.', 'designer-designs' ); ?></p>
	<?php endif; ?>
</main>
<?php
get_footer();
