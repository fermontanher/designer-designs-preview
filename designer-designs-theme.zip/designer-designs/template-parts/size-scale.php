<?php
/**
 * "One piece, three sizes": the same piece shown at Small, Medium and Large, side by side,
 * next to a person outline for scale. Used on the homepage and the Size guide page.
 *
 * @package designer-designs
 */

defined( 'ABSPATH' ) || exit;

$dd_pid  = function_exists( 'wc_get_product_id_by_sku' ) ? wc_get_product_id_by_sku( 'DD-PEBBLE' ) : 0;
$dd_prod = $dd_pid ? wc_get_product( $dd_pid ) : null;
if ( ! $dd_prod ) {
	return;
}
$dd_data  = dd_swatch_data( $dd_prod );
$dd_sizes = array();
foreach ( $dd_data as $dd_key => $dd_opts ) {
	if ( false !== strpos( $dd_key, 'size' ) ) {
		$dd_sizes = $dd_opts;
	}
}
if ( ! $dd_sizes ) {
	return;
}
$dd_img     = wp_get_attachment_image_url( $dd_prod->get_image_id(), 'dd-large' );
$dd_heights = array( 'small' => 56, 'medium' => 80, 'large' => 100 );
$dd_uses    = array(
	'small'  => __( 'Shelves, consoles and tabletops', 'designer-designs' ),
	'medium' => __( 'Beside a sofa, bed or reading chair', 'designer-designs' ),
	'large'  => __( 'A floor statement for a whole corner', 'designer-designs' ),
);
?>
<div class="dd-scale" data-dd-scale>
	<div class="dd-scale__stage" aria-hidden="true">
		<?php foreach ( $dd_sizes as $dd_slug => $dd_s ) : ?>
			<?php $dd_h = $dd_heights[ $dd_slug ] ?? 80; ?>
			<a class="dd-scale__piece" data-size="<?php echo esc_attr( $dd_slug ); ?>" href="<?php echo esc_url( add_query_arg( 'attribute_pa_size', $dd_slug, $dd_prod->get_permalink() ) ); ?>" tabindex="-1" style="--h:<?php echo esc_attr( $dd_h ); ?>%">
				<span class="dd-scale__img" style="background-image:url('<?php echo esc_url( $dd_img ); ?>')"></span>
			</a>
		<?php endforeach; ?>
	</div>
	<div class="dd-scale__labels" role="list">
		<?php foreach ( $dd_sizes as $dd_slug => $dd_s ) : ?>
			<a class="dd-scale__label" role="listitem" data-size="<?php echo esc_attr( $dd_slug ); ?>" href="<?php echo esc_url( add_query_arg( 'attribute_pa_size', $dd_slug, $dd_prod->get_permalink() ) ); ?>">
				<strong><?php echo esc_html( $dd_s['label'] ); ?></strong>
				<?php if ( ! empty( $dd_s['note'] ) ) : ?><span><?php echo esc_html( $dd_s['note'] ); ?></span><?php endif; ?>
				<span class="dd-muted"><?php echo esc_html( $dd_uses[ $dd_slug ] ?? '' ); ?></span>
				<?php if ( ! empty( $dd_s['minLabel'] ) ) : ?><em><?php echo esc_html( sprintf( __( 'from %s', 'designer-designs' ), $dd_s['minLabel'] ) ); ?></em><?php endif; ?>
			</a>
		<?php endforeach; ?>
	</div>
	<p class="dd-scale__note dd-muted"><?php echo esc_html( sprintf( __( 'Shown: %s, sizes drawn relative to each other. Every piece in the collection is made in Small, Medium and Large, with exact measurements on each product.', 'designer-designs' ), $dd_prod->get_name() ) ); ?></p>
</div>
