<?php
/**
 * Plugin Name: Designer Designs — starter content
 * Description: Fills a fresh WooCommerce shop with the Designer Designs categories, products (photos from the Etsy shop), colours and sizes, delivery rules, test payments and help pages. Run once; everything it creates can be edited or deleted in the dashboard afterwards. Prices marked TEST are placeholders.
 * Version: 0.2.0
 * Author: Fernanda Montanher
 * Requires Plugins: woocommerce
 * Text Domain: dd-starter
 *
 * @package dd-starter
 */

defined( 'ABSPATH' ) || exit;

define( 'DD_STARTER_VERSION', '0.2.0' );

register_activation_hook( __FILE__, function () {
	// WooCommerce may not be loaded inside the activation request on some hosts: defer to the next admin load.
	update_option( 'dd_starter_pending', 1 );
} );

add_action( 'admin_init', function () {
	if ( ! class_exists( 'WooCommerce' ) || ! current_user_can( 'manage_options' ) ) {
		return;
	}
	// First run, or an updated version of this plugin (re-applies changes; matched by SKU, safe to repeat).
	if ( get_option( 'dd_starter_pending' ) || DD_STARTER_VERSION !== get_option( 'dd_starter_version' ) ) {
		delete_option( 'dd_starter_pending' );
		update_option( 'dd_starter_version', DD_STARTER_VERSION );
		dd_starter_seed();
	}
} );

add_action( 'admin_notices', function () {
	if ( get_transient( 'dd_starter_done' ) ) {
		delete_transient( 'dd_starter_done' );
		echo '<div class="notice notice-success"><p><strong>Designer Designs:</strong> categories, products, delivery rules and help pages are ready. Prices marked TEST and text in [brackets] still need Elaine\'s real details.</p></div>';
	}
} );

if ( defined( 'WP_CLI' ) && WP_CLI ) {
	WP_CLI::add_command( 'dd seed', function () {
		dd_starter_seed();
		WP_CLI::success( 'Designer Designs starter content created.' );
	} );
}

/** Empty price → "Price on request" (Black Totem until Elaine confirms). */
add_filter( 'woocommerce_empty_price_html', fn() => '<span class="dd-por">' . esc_html__( 'Price on request', 'dd-starter' ) . '</span>' );

/* ======================================================================== */

/** Import a bundled image into the media library once (keyed by file name). */
function dd_starter_image( $file, $alt = '', $caption = '' ) {
	$existing = get_posts( array( 'post_type' => 'attachment', 'meta_key' => '_dd_src', 'meta_value' => $file, 'numberposts' => 1, 'fields' => 'ids' ) ); // phpcs:ignore
	if ( $existing ) {
		return (int) $existing[0];
	}
	require_once ABSPATH . 'wp-admin/includes/image.php';
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/media.php';

	$src = __DIR__ . '/images/' . $file;
	if ( ! file_exists( $src ) ) {
		return 0;
	}
	$upload = wp_upload_bits( $file, null, file_get_contents( $src ) ); // phpcs:ignore
	if ( ! empty( $upload['error'] ) ) {
		return 0;
	}
	$id = wp_insert_attachment( array(
		'post_mime_type' => 'image/jpeg',
		'post_title'     => $alt ? $alt : pathinfo( $file, PATHINFO_FILENAME ),
		'post_excerpt'   => $caption,
		'post_status'    => 'inherit',
	), $upload['file'] );
	wp_update_attachment_metadata( $id, wp_generate_attachment_metadata( $id, $upload['file'] ) );
	update_post_meta( $id, '_wp_attachment_image_alt', $alt );
	update_post_meta( $id, '_dd_src', $file );
	return (int) $id;
}

/** Create (or fetch) a product category. */
function dd_starter_cat( $name, $slug, $parent = 0, $order = 0, $note = '', $desc = '' ) {
	$t = get_term_by( 'slug', $slug, 'product_cat' );
	if ( ! $t ) {
		$r = wp_insert_term( $name, 'product_cat', array( 'slug' => $slug, 'parent' => $parent, 'description' => $desc ) );
		if ( is_wp_error( $r ) ) {
			return 0;
		}
		$id = (int) $r['term_id'];
	} else {
		$id = (int) $t->term_id;
	}
	update_term_meta( $id, 'order', $order );
	if ( $note ) {
		update_term_meta( $id, 'dd_note', $note );
	}
	return $id;
}

/** Global attribute with terms. */
function dd_starter_attribute( $name, $slug, $terms ) {
	$tax = 'pa_' . $slug;
	if ( ! wc_attribute_taxonomy_id_by_name( $slug ) ) {
		wc_create_attribute( array( 'name' => $name, 'slug' => $slug, 'type' => 'select', 'order_by' => 'menu_order', 'has_archives' => false ) );
		delete_transient( 'wc_attribute_taxonomies' );
	}
	if ( ! taxonomy_exists( $tax ) ) {
		register_taxonomy( $tax, array( 'product' ), array( 'hierarchical' => false, 'show_ui' => false, 'query_var' => true, 'rewrite' => false ) );
	}
	$i = 0;
	foreach ( $terms as $t ) {
		$term = get_term_by( 'slug', $t['slug'], $tax );
		if ( ! $term ) {
			$r       = wp_insert_term( $t['name'], $tax, array( 'slug' => $t['slug'], 'description' => $t['desc'] ?? '' ) );
			$term_id = is_wp_error( $r ) ? 0 : $r['term_id'];
		} else {
			$term_id = $term->term_id;
			if ( array_key_exists( 'desc', $t ) || 'pa_size' === $tax ) {
				wp_update_term( $term_id, $tax, array( 'description' => $t['desc'] ?? '' ) );
			}
		}
		if ( $term_id ) {
			update_term_meta( $term_id, 'order', $i++ );
			if ( ! empty( $t['hex'] ) ) {
				update_term_meta( $term_id, 'dd_hex', $t['hex'] );
			}
		}
	}
	return $tax;
}

/** The whole seed. Safe to run twice: products are matched by SKU. */
function dd_starter_seed() {
	if ( ! class_exists( 'WooCommerce' ) ) {
		return;
	}
	@set_time_limit( 300 ); // phpcs:ignore

	/* ---- Shop basics ---- */
	update_option( 'blogname', 'Designer Designs' );
	update_option( 'blogdescription', 'Handmade sculptural homeware from a London studio' );
	update_option( 'woocommerce_currency', 'GBP' );
	update_option( 'woocommerce_default_country', 'GB' );
	update_option( 'woocommerce_specific_allowed_countries', array( 'GB' ) );
	update_option( 'woocommerce_price_num_decimals', 2 );
	update_option( 'woocommerce_enable_reviews', 'yes' );
	update_option( 'woocommerce_review_rating_required', 'yes' );
	update_option( 'woocommerce_enable_ajax_add_to_cart', 'yes' );
	update_option( 'woocommerce_cart_redirect_after_add', 'no' );
	update_option( 'woocommerce_weight_unit', 'kg' );
	update_option( 'woocommerce_dimension_unit', 'cm' );
	update_option( 'woocommerce_coming_soon', 'no' );
	update_option( 'dd_default_delivery', 'Tracked UK delivery in [X] working days once your piece is made. Returns within [X] days on standard pieces; customised pieces are made for you and can\'t be returned.' );

	/* ---- Categories (navigation order = order meta) ---- */
	$c_light = dd_starter_cat( 'Lighting', 'lighting', 0, 1, 'Floor lamps, pendants, shades' );
	$c_floor = dd_starter_cat( 'Floor lamps', 'floor-lamps', $c_light, 1 );
	dd_starter_cat( 'Table lamps', 'table-lamps', $c_light, 2 );
	$c_pend  = dd_starter_cat( 'Pendant lights', 'pendant-lights', $c_light, 3 );
	$c_shade = dd_starter_cat( 'Lamp shades', 'lamp-shades', $c_light, 4 );
	$c_vases = dd_starter_cat( 'Vases', 'vases', 0, 2, 'Oversized and table vases' );
	$c_fvase = dd_starter_cat( 'Oversized floor vases', 'floor-vases', $c_vases, 1 );
	$c_tvase = dd_starter_cat( 'Table vases', 'table-vases', $c_vases, 2 );
	$c_sculp = dd_starter_cat( 'Sculptures', 'sculptures', 0, 3, 'Floor and table pieces' );
	$c_fscul = dd_starter_cat( 'Floor sculptures', 'floor-sculptures', $c_sculp, 1 );
	dd_starter_cat( 'Table sculptures', 'table-sculptures', $c_sculp, 2 );
	$c_bowls = dd_starter_cat( 'Bowls & platters', 'bowls-platters', 0, 4, 'Display bowls, platters' );
	$c_dbowl = dd_starter_cat( 'Decorative bowls', 'decorative-bowls', $c_bowls, 1 );
	dd_starter_cat( 'Platters', 'platters', $c_bowls, 2 );
	$c_wall  = dd_starter_cat( 'Wall art', 'wall-art', 0, 5, 'Hand-formed wall pieces' );
	$c_wset  = dd_starter_cat( 'Wall art sets', 'wall-art-sets', $c_wall, 1 );
	dd_starter_cat( 'Single pieces', 'single-wall-pieces', $c_wall, 2 );
	$c_clock = dd_starter_cat( 'Clocks', 'clocks', 0, 6, 'Coming soon', 'Wall and table clocks in the same hand-worked finishes. Leave your email and we\'ll tell you first.' );
	update_term_meta( $c_clock, 'dd_soon', 1 );
	dd_starter_cat( 'Wall clocks', 'wall-clocks', $c_clock, 1 );
	dd_starter_cat( 'Table clocks', 'table-clocks', $c_clock, 2 );

	/* ---- Attributes ---- */
	$pa_colour = dd_starter_attribute( 'Colour', 'colour', array(
		array( 'name' => 'Sculptural black', 'slug' => 'sculptural-black', 'hex' => '#242424' ),
		array( 'name' => 'Stone grey', 'slug' => 'stone-grey', 'hex' => '#7a7670' ),
		array( 'name' => 'Earth brown', 'slug' => 'earth-brown', 'hex' => '#7a503b' ),
		array( 'name' => 'Chalk white', 'slug' => 'chalk-white', 'hex' => '#ebe6dc' ),
		array( 'name' => 'Warm beige', 'slug' => 'warm-beige', 'hex' => '#c8b597' ),
	) );
	$pa_size = dd_starter_attribute( 'Size', 'size', array(
		array( 'name' => 'Small', 'slug' => 'small' ),
		array( 'name' => 'Medium', 'slug' => 'medium' ),
		array( 'name' => 'Large', 'slug' => 'large' ),
	) );

	$materials = 'Handmade from organic paper and natural clay with polymer additives. Ultra-matte, richly textured surface.';
	$care      = 'Arrives with a detail brush, a soft cleaning cloth and a care card for its finish. Dust gently and keep it dry: no water or sprays.';
	$lead      = 'Made to order: ships in [3 to 4] weeks';

	/* ---- The hero product: Pebble Floor Lamp (variable: size × colour) ---- */
	$g = array(
		dd_starter_image( 'lamp-02.jpg', 'Pebble Floor Lamp in a bright hallway' ),
		dd_starter_image( 'lamp-01.jpg', 'The lamp beside a person, for scale' ),
		dd_starter_image( 'lamp-03.jpg', 'Lit in a bedroom at dusk', 'In the bedroom, a warm pool of light at dusk' ),
		dd_starter_image( 'lamp-04.jpg', 'Lit in a dining room at night', 'In the dining room, sculpture by day, glow by night' ),
		dd_starter_image( 'lamp-07.jpg', 'In a living room with a seated person' ),
		dd_starter_image( 'lamp-08.jpg', 'In a dining room by day' ),
		dd_starter_image( 'lamp-05.jpg', 'Close-up of the stacked pebble forms' ),
		dd_starter_image( 'lamp-06.jpg', 'Close-up of the matte black texture' ),
	);

	$pid = wc_get_product_id_by_sku( 'DD-PEBBLE' );
	$p   = $pid ? wc_get_product( $pid ) : new WC_Product_Variable();
	$p->set_name( 'Pebble Floor Lamp' );
	$p->set_slug( 'pebble-floor-lamp' );
	$p->set_sku( 'DD-PEBBLE' );
	$p->set_status( 'publish' );
	$p->set_featured( true );
	$p->set_menu_order( 1 );
	$p->set_short_description( 'A stack of hand-shaped pebble forms under a simple cylindrical shade. A bold sculpture by day and a warm, quiet glow at night.' );
	$p->set_description( 'Stacked, pebble-like forms with a simple cylindrical shade. Each form is shaped individually, so angles and texture vary slightly from lamp to lamp. Medium is 30 cm wide and 160 cm tall.' );
	$p->set_category_ids( array( $c_light, $c_floor ) );
	$p->set_image_id( $g[0] );
	$p->set_gallery_image_ids( array_slice( $g, 1 ) );
	$p->set_reviews_allowed( true );
	$colour_terms = array( 'sculptural-black', 'stone-grey', 'earth-brown', 'chalk-white', 'warm-beige' );
	$size_terms   = array( 'small', 'medium', 'large' );
	$a1           = new WC_Product_Attribute();
	$a1->set_id( wc_attribute_taxonomy_id_by_name( 'size' ) );
	$a1->set_name( $pa_size );
	$a1->set_options( array_map( fn( $s ) => get_term_by( 'slug', $s, $pa_size )->term_id, $size_terms ) );
	$a1->set_visible( true );
	$a1->set_variation( true );
	$a1->set_position( 0 );
	$a2 = new WC_Product_Attribute();
	$a2->set_id( wc_attribute_taxonomy_id_by_name( 'colour' ) );
	$a2->set_name( $pa_colour );
	$a2->set_options( array_map( fn( $s ) => get_term_by( 'slug', $s, $pa_colour )->term_id, $colour_terms ) );
	$a2->set_visible( true );
	$a2->set_variation( true );
	$a2->set_position( 1 );
	$p->set_attributes( array( $a1, $a2 ) );
	$p->set_default_attributes( array( $pa_size => 'medium', $pa_colour => 'sculptural-black' ) );
	$p->update_meta_data( '_dd_kicker', 'Floor lamp, handmade in London' );
	$p->update_meta_data( '_dd_lead_time', $lead );
	$p->update_meta_data( '_dd_materials', $materials . ' Bulb and fitting: [to confirm].' );
	$p->update_meta_data( '_dd_care', $care );
	$p->update_meta_data( '_dd_story', 'Paper and clay are layered in the London studio, then finished in an ultra-matte surface that keeps the small variations of making. A bold sculpture by day, and a warm, quiet glow at night.' );
	$p->update_meta_data( '_dd_story_title', 'Every pebble is shaped by hand, so no two lamps are the same' );
	$p->update_meta_data( '_dd_size_s', '[W × H cm]' );
	$p->update_meta_data( '_dd_size_m', '30 × 160 cm' );
	$p->update_meta_data( '_dd_size_l', '[W × H cm]' );
	$pebble_id = $p->save();

	// Variations: Medium is the real Etsy price (converted); Small and Large are TEST placeholders.
	$size_price = array( 'small' => 895, 'medium' => 1155, 'large' => 1395 );
	$existing   = array();
	foreach ( wc_get_product( $pebble_id )->get_children() as $vid ) {
		$v                                                                    = wc_get_product( $vid );
		$existing[ $v->get_attribute( $pa_size ) . '|' . $v->get_attribute( $pa_colour ) ] = $vid;
	}
	foreach ( $size_terms as $s ) {
		foreach ( $colour_terms as $c ) {
			$sname = get_term_by( 'slug', $s, $pa_size )->name;
			$cname = get_term_by( 'slug', $c, $pa_colour )->name;
			$v     = isset( $existing[ $sname . '|' . $cname ] ) ? wc_get_product( $existing[ $sname . '|' . $cname ] ) : new WC_Product_Variation();
			$v->set_parent_id( $pebble_id );
			$v->set_attributes( array( $pa_size => $s, $pa_colour => $c ) );
			$v->set_regular_price( (string) $size_price[ $s ] );
			$v->set_status( 'publish' );
			$v->set_stock_status( 'instock' );
			$v->set_sku( 'DD-PEBBLE-' . strtoupper( substr( $s, 0, 1 ) ) . '-' . strtoupper( substr( $c, 0, 3 ) ) );
			if ( 'medium' === $s ) {
				$v->set_length( 30 );
				$v->set_width( 30 );
				$v->set_height( 160 );
			}
			$v->save();
		}
	}
	WC_Product_Variable::sync( $pebble_id );

	/* ---- Simple products (photos and prices from the Etsy shop, converted to £) ---- */
	$simple = array(
		array( 'DD-MUSHROOM', 'Pebble Floor Lamp, Mushroom Shade', 935, 'p-mushroom-lamp.jpg', array( $c_light, $c_floor ), 'The pebble stack with a soft, domed mushroom shade.', 'Made to order', false, 2 ),
		array( 'DD-DRUM', 'Layered Drum Floor Lamp', 475, 'p-drum-lamp.jpg', array( $c_light, $c_floor ), 'Layered drum forms under a 35 cm shade.', '35 cm shade', false, 3 ),
		array( 'DD-SHADE', 'Bronze Brown Lamp Shade', 158, 'p-shade.jpg', array( $c_light, $c_shade, $c_pend ), 'A hand-formed pendant shade in a bronze brown finish.', 'Pendant shade', false, 4, true ),
		array( 'DD-SPHERE', 'Sphere Floor Vase', 609, 'p-sphere-vase.jpg', array( $c_vases, $c_fvase ), 'An oversized sphere vase that sits on the floor.', 'Oversized floor vase', false, 1 ),
		array( 'DD-TIERED', 'Tiered Statement Vase', 147, 'p-tiered-vase.jpg', array( $c_vases, $c_tvase ), 'Stacked tiers, for a table or the floor.', 'Table or floor', false, 2, true ),
		array( 'DD-WAVE', 'Wave Vase, White', 273, 'p-wave-vase.jpg', array( $c_vases, $c_tvase ), 'A sculptural vase with a flowing wave profile.', 'Sculptural vase', true, 3 ),
		array( 'DD-CAIRN', 'Cairn Floor Sculpture', 567, 'p-cairn.jpg', array( $c_sculp, $c_fscul ), 'Balanced stones, shaped by hand from paper and clay.', 'Floor sculpture', true, 1 ),
		array( 'DD-TOTEM', 'Black Totem Sculpture', null, 'p-black-sculpture.jpg', array( $c_sculp, $c_fscul ), 'A tall totem in sculptural black.', 'Floor sculpture', false, 2 ),
		array( 'DD-RIPPLE', 'Ripple Display Bowl', 84, 'p-ripple-bowl.jpg', array( $c_bowls, $c_dbowl ), 'A rippled display bowl, up to 60 cm wide.', 'Up to 60 cm wide', true, 1, true ),
		array( 'DD-VESSEL', 'Low Vessel Bowl', 368, 'p-bowl-vase.jpg', array( $c_bowls, $c_dbowl ), 'A low, wide statement bowl.', 'Statement bowl', false, 2 ),
		array( 'DD-WALLART', 'Organic Wall Art', 68, 'p-wall-art.jpg', array( $c_wall, $c_wset ), 'A set of hand-formed hanging pieces.', 'Set of hanging pieces', false, 1, true ),
	);
	$ids = array( 'DD-PEBBLE' => $pebble_id );
	$size_attr = function () use ( $pa_size, $size_terms ) {
		$a = new WC_Product_Attribute();
		$a->set_id( wc_attribute_taxonomy_id_by_name( 'size' ) );
		$a->set_name( $pa_size );
		$a->set_options( array_map( fn( $t ) => get_term_by( 'slug', $t, $pa_size )->term_id, $size_terms ) );
		$a->set_visible( true );
		$a->set_variation( true );
		return $a;
	};
	// Every piece comes in three sizes (client: "size variation is one of our biggest selling points").
	// Medium keeps the real Etsy price; Small (x0.7) and Large (x1.4) are TEST placeholders until Elaine confirms.
	$round5 = fn( $v ) => (int) ( round( $v / 5 ) * 5 );
	foreach ( $simple as $s ) {
		list( $sku, $name, $price, $img, $cats, $short, $meta, $featured, $order ) = $s;
		$extra = ! empty( $s[9] );
		$id    = wc_get_product_id_by_sku( $sku );
		$sized = null !== $price;
		if ( $id && $sized ) {
			wp_set_object_terms( $id, 'variable', 'product_type' );
			wc_delete_product_transients( $id );
			clean_post_cache( $id );
		}
		if ( $sized ) {
			$p = $id ? new WC_Product_Variable( $id ) : new WC_Product_Variable();
		} else {
			$p = $id ? wc_get_product( $id ) : new WC_Product_Simple();
			$p->set_regular_price( '' );
		}
		$p->set_name( $name );
		$p->set_sku( $sku );
		$p->set_status( 'publish' );
		$p->set_category_ids( $cats );
		$p->set_image_id( dd_starter_image( $img, $name ) );
		$p->set_short_description( $short );
		$p->set_description( $short . ' Each piece is shaped by hand, so texture and proportions vary slightly. [Dimensions to confirm.]' );
		$p->set_featured( $featured );
		$p->set_menu_order( $order );
		$p->set_reviews_allowed( true );
		$p->update_meta_data( '_dd_card_meta', $meta );
		$p->update_meta_data( '_dd_lead_time', $lead );
		$p->update_meta_data( '_dd_materials', $materials );
		$p->update_meta_data( '_dd_care', $care );
		if ( $sized ) {
			$p->set_attributes( array( $size_attr() ) );
			$p->set_default_attributes( array( $pa_size => 'medium' ) );
			foreach ( array( '_dd_size_s', '_dd_size_m', '_dd_size_l' ) as $mk ) {
				if ( ! $p->get_meta( $mk ) ) {
					$p->update_meta_data( $mk, '[W × H cm]' );
				}
			}
		}
		$ids[ $sku ] = $p->save();
		if ( $sized ) {
			$have = array();
			foreach ( wc_get_product( $ids[ $sku ] )->get_children() as $vid ) {
				$v = wc_get_product( $vid );
				if ( $v ) {
					$have[ $v->get_attribute( $pa_size ) ] = $vid;
				}
			}
			$prices = array( 'small' => $round5( $price * 0.7 ), 'medium' => $price, 'large' => $round5( $price * 1.4 ) );
			foreach ( $size_terms as $t ) {
				$tname = get_term_by( 'slug', $t, $pa_size )->name;
				$v     = isset( $have[ $tname ] ) ? wc_get_product( $have[ $tname ] ) : new WC_Product_Variation();
				$v->set_parent_id( $ids[ $sku ] );
				$v->set_attributes( array( $pa_size => $t ) );
				$v->set_regular_price( (string) $prices[ $t ] );
				$v->set_status( 'publish' );
				$v->set_stock_status( 'instock' );
				$v->set_sku( $sku . '-' . strtoupper( substr( $t, 0, 1 ) ) );
				$v->save();
			}
			WC_Product_Variable::sync( $ids[ $sku ] );
			wc_delete_product_transients( $ids[ $sku ] );
		}
		if ( $extra ) {
			if ( ! term_exists( 'little-extra', 'product_tag' ) ) {
				wp_insert_term( 'Little extra', 'product_tag', array( 'slug' => 'little-extra' ) );
			}
			wp_set_object_terms( $ids[ $sku ], array( 'little-extra' ), 'product_tag' );
		}
	}

	/* ---- "Add a little extra" and "Complete the look" ---- */
	$set = function ( $sku, $cross, $up = array() ) use ( $ids ) {
		$p = wc_get_product( $ids[ $sku ] );
		$p->set_cross_sell_ids( array_map( fn( $k ) => $ids[ $k ], $cross ) );
		if ( $up ) {
			$p->set_upsell_ids( array_map( fn( $k ) => $ids[ $k ], $up ) );
		}
		$p->save();
	};
	$set( 'DD-PEBBLE', array( 'DD-RIPPLE', 'DD-WALLART', 'DD-WAVE' ) );
	foreach ( array( 'DD-MUSHROOM', 'DD-DRUM', 'DD-SPHERE', 'DD-CAIRN', 'DD-TOTEM', 'DD-VESSEL' ) as $k ) {
		$set( $k, array( 'DD-RIPPLE', 'DD-WALLART', 'DD-SHADE' ) );
	}
	foreach ( array( 'DD-WAVE', 'DD-TIERED' ) as $k ) {
		$set( $k, array( 'DD-RIPPLE', 'DD-WALLART', 'DD-SHADE' ) );
	}

	/* Category images */
	foreach ( array( $c_light => $g[0], $c_vases => 'DD-SPHERE', $c_sculp => 'DD-CAIRN', $c_bowls => 'DD-RIPPLE', $c_wall => 'DD-WALLART' ) as $term => $src ) {
		$img = is_int( $src ) ? $src : wc_get_product( $ids[ $src ] )->get_image_id();
		update_term_meta( $term, 'thumbnail_id', $img );
	}

	/* ---- Delivery: UK only, free over £150, flat rate below (TEST amount) ---- */
	$zone_id = (int) get_option( 'dd_starter_zone' );
	$zone    = $zone_id ? new WC_Shipping_Zone( $zone_id ) : null;
	if ( ! $zone || ! $zone->get_id() ) {
		$zone = new WC_Shipping_Zone();
		$zone->set_zone_name( 'United Kingdom' );
		$zone->add_location( 'GB', 'country' );
		$zone->save();
		$i = $zone->add_shipping_method( 'free_shipping' );
		update_option( 'woocommerce_free_shipping_' . $i . '_settings', array( 'title' => 'Free tracked UK delivery', 'requires' => 'min_amount', 'min_amount' => '150', 'ignore_discounts' => 'no' ) );
		$j = $zone->add_shipping_method( 'flat_rate' );
		update_option( 'woocommerce_flat_rate_' . $j . '_settings', array( 'title' => 'Tracked UK delivery', 'tax_status' => 'none', 'cost' => '15' ) );
		update_option( 'dd_starter_zone', $zone->get_id() );
	}

	/* ---- Test payments only (Stripe/PayPal/Klarna get connected on the live site) ---- */
	update_option( 'woocommerce_cheque_settings', array( 'enabled' => 'yes', 'title' => 'Test payment (no money is taken)', 'description' => 'This is a test shop. Place the order to see the confirmation page and emails.', 'instructions' => 'Test order — nothing to pay.' ) );
	update_option( 'woocommerce_bacs_settings', array( 'enabled' => 'yes', 'title' => 'Bank transfer', 'description' => 'Pay by bank transfer. Your piece goes on the workbench once the payment clears.' ) );

	/* ---- Help & studio pages (footer) ---- */
	$pages = array(
		'our-story'    => array( 'Our story', "Designer Designs is a small studio in London making sculptural homeware by hand from paper and clay.\n\n[Elaine's story: how the studio started, the hands behind the work, why imperfections are kept.]\n\nEvery purchase also supports Lupus UK." ),
		'materials'    => array( 'Materials & process', "Organic paper and natural clay are layered by hand, then finished in matte black, gold and earth tones. We keep the marks of making instead of sanding them away.\n\n[Steps of the process and photos from the studio.]" ),
		'delivery'     => array( 'Delivery & lead times', "Every piece is made to order. The lead time is shown on each product before you buy.\n\nFree tracked UK delivery on orders over £150. Below that, tracked delivery is £[15].\n\n[Courier, delivery days, large items, international orders.]" ),
		'returns'      => array( 'Returns', "Returns within [X] days on standard pieces, in their original packaging. Customised pieces are made for you and can't be returned.\n\nThe Love It guarantee: if something isn't right for your room, talk to us and we'll put it right." ),
		'size-guide'   => array( 'Size guide', "Every piece is made to order in three sizes, so it can fit a shelf, a side table or stand on its own as a floor statement.\n\nThe exact measurements for each size are shown on every product, right next to the size buttons.\n\n[Elaine to confirm the size bands for each collection.]" ),
		'care'         => array( 'Care guides', "Every piece arrives with a detail brush, a soft cloth and a care card written for its finish.\n\nDust gently with the brush. Keep pieces dry: no water, sprays or polish.\n\n[Care notes for each finish.]" ),
		'faq'          => array( 'FAQ', "<strong>How long will my piece take?</strong>\nEach product shows its lead time before you buy.\n\n<strong>What sizes do you make?</strong>\nEvery piece comes in Small, Medium and Large. See the size guide, or the measurements on each product.\n\n<strong>Can I order a size or colour that isn't listed?</strong>\nYes. Ask for a custom piece and we'll quote it.\n\n<strong>Do you deliver outside the UK?</strong>\n[To confirm.]" ),
		'contact'      => array( 'Contact us', "Questions about a piece, an order or a commission? Email [studio email] and we'll reply within [one working day].\n\nDesigner Designs Studio, London." ),
		'commissions'  => array( 'Custom commissions', "Need another size or finish? Tell us about your room, the size and the colour you have in mind, and we'll quote a piece made for you.\n\nEmail [studio email] with a photo of the space." ),
		'trade'        => array( 'Trade accounts', "For interior designers, stylists and hospitality projects. [Trade terms and how to apply.]" ),
		'giving-back'  => array( 'Giving back', "Every purchase supports Lupus UK. [How much is donated and why it matters to the studio.]" ),
		'terms'        => array( 'Terms', '[Terms and conditions to be provided.]' ),
		'cookies'      => array( 'Cookies', '[Cookie policy to be provided. Analytics cookies are only set after consent.]' ),
	);
	foreach ( $pages as $slug => $page ) {
		if ( ! get_page_by_path( $slug ) ) {
			wp_insert_post( array( 'post_type' => 'page', 'post_status' => 'publish', 'post_name' => $slug, 'post_title' => $page[0], 'post_content' => wpautop( $page[1] ) ) );
		}
	}
	$privacy = (int) get_option( 'wp_page_for_privacy_policy' );
	if ( $privacy ) {
		wp_update_post( array( 'ID' => $privacy, 'post_status' => 'publish', 'post_name' => 'privacy-policy' ) );
	}

	/* Homepage stays the theme front page; remove the sample content. */
	foreach ( array( 'hello-world', 'sample-page' ) as $slug ) {
		$post = get_page_by_path( $slug, OBJECT, array( 'post', 'page' ) );
		if ( $post ) {
			wp_delete_post( $post->ID, true );
		}
	}
	update_option( 'show_on_front', 'posts' );
	update_option( 'permalink_structure', '/%postname%/' );
	flush_rewrite_rules();
	wc_delete_product_transients();
	set_transient( 'dd_starter_done', 1, 60 );
}
